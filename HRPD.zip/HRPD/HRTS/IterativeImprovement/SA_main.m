function sequenceMat=SA_main()

global TaskSet;
global TransportRobotSet;
global PickRobotSet;
global subtaskDistributionMat;
global blockWidthVec;
global subtaskIDCell;
global subtaskStationCell;
global subtaskPTimeMat;

m = size(TransportRobotSet,1);
Csum = sum(blockWidthVec);

initialSequenceMat = TSAppend(1);
fitnessfcn = @(x) SA_fitness(x);

options = optimoptions(@simulannealbnd,'DataType', 'custom', ...
    'AnnealingFcn', @SA_anneal, 'MaxStallIterations',100, 'ReannealInterval', 100, ...
    'PlotFcn', {@saplotf,@saplotbestf});

sequenceMat = simulannealbnd(fitnessfcn,initialSequenceMat,[],[],options);

end