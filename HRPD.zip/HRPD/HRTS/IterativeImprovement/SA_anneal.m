function sequenceMat = SA_anneal(optimValues,problemData)
% NEWX = SA_neighbor(optimValues,problemData) generate a point based
% on the current point and the current temperature
sequenceMat = optimValues.x;
% This loop will generate a neighbor of "distance" equal to
% optimValues.temperature.  It does this by generating a neighbor to the
% current schedule, and then generating a neighbor to that neighbor, and so
% on until it has generated enough neighbors.

%% fast annealing
for i = 1:floor(optimValues.temperature)+1
    sequenceMat = neighbor(sequenceMat);
end

end

function newSeqMat = neighbor(currentSeqMat)
global subtaskDistributionMat;
global blockWidthVec;
global subtaskPTimeMat;

while( exist('newSeqMat','var') == 0 )
    %% randomly decide which operation is to be switched
    [rows,cols] = find(subtaskPTimeMat~=0);
    randNum = randi([1,size(rows,1)]);
    r = rows(randNum,1);
    c = cols(randNum,1);
    
    transportID = r;
    [pickID,blockID] = col2jk(c,blockWidthVec);    
    col1 = jk2col(pickID,1,blockWidthVec);
    col2 = jk2col(pickID,blockWidthVec(1,pickID),blockWidthVec);
    
    [rowOrders,colOrders] = sequence2order(currentSeqMat);
    
    %% randomly decide which direction to interchange
    currentRank = currentSeqMat(r,c);
    directions = randperm(4);
    
    for direction = directions % four directions. random directions
        switch direction
            case 1 % row rank - 1
                if currentRank - 1 > 0
                    index = find(currentSeqMat(r,:) == currentRank - 1, 1);
                    if ~isempty(index)
                        if index <= totalBlock + pickupTaskBlockMaxNum(1,c) && index >= totalBlock + 1 % if they are in the same block
                            newSeqMat = currentSeqMat;
                            newSeqMat(r,index) = currentRank;
                            newSeqMat(r,totalBlock + block) = currentRank - 1;
                        else
                            temp = rowOrders (r,index);
                            rowOrders (r,index) = rowOrders (r,totalBlock + block );
                            rowOrders (r,totalBlock + block ) = temp;
                            newSeqMat = sequence2rank(rowOrders,colSequence,pickupTaskNumMat,pickupTaskBlockMaxNum);
                        end
                        break;
                    end
                end
                
            case 2 % row rank + 1
                index = find(currentSeqMat(r,:) == currentRank + 1, 1);
                if ~isempty(index)
                    if index <= totalBlock + pickupTaskBlockMaxNum(1,c) && index >= totalBlock + 1 % if they are in the same block
                        newSeqMat = currentSeqMat;
                        newSeqMat(r,index) = currentRank;
                        newSeqMat(r,totalBlock + block) = currentRank + 1;
                    else
                        temp = rowOrders (r,index);
                        rowOrders (r,index) = rowOrders (r,totalBlock + block );
                        rowOrders (r,totalBlock + block ) = temp;
                        newSeqMat = sequence2rank(rowOrders,colSequence,pickupTaskNumMat,pickupTaskBlockMaxNum);
                    end
                    break;
                else
                    continue;
                end
            case 3 %columns rank -1
                if currentRank - 1 > 0
                    [rows,cols] = find(currentSeqMat(:,totalBlock+1:totalBlock+pickupTaskBlockMaxNum(1,c)) == currentRank - 1);
                    if ~isempty(rows)
                        if cols <=  pickupTaskBlockMaxNum(1,c) && cols >= 1 && rows == r % if they are in the same block
                            newSeqMat = currentSeqMat;
                            newSeqMat(rows,totalBlock + cols) = currentRank;
                            newSeqMat(r,totalBlock + block) = currentRank - 1;
                        else
                            temp = colSequence (rows,totalBlock + cols) ;
                            colSequence (rows,totalBlock + cols) = colSequence (r,totalBlock + block );
                            colSequence (r,totalBlock + block ) = temp;
                            newSeqMat = sequence2rank(rowOrders,colSequence,pickupTaskNumMat,pickupTaskBlockMaxNum);
                        end
                        break;
                    else
                        continue;
                    end
                else
                    continue;
                end
                
            case 4 % columns rank + 1
                [rows,cols] = find(currentSeqMat(:,totalBlock+1:totalBlock+pickupTaskBlockMaxNum(1,c)) == currentRank + 1);
                if ~isempty(rows)
                    if cols <= pickupTaskBlockMaxNum(1,c) && cols >= 1 && rows == r % if they are in the same block
                        newSeqMat = currentSeqMat;
                        newSeqMat(rows,totalBlock + cols) = currentRank;
                        newSeqMat(r,totalBlock + block) = currentRank + 1;
                    else
                        temp = colSequence (rows,totalBlock + cols) ;
                        colSequence (rows,totalBlock + cols) = colSequence (r,totalBlock + block );
                        colSequence (r,totalBlock + block ) = temp;
                        newSeqMat = sequence2rank(rowOrders,colSequence,pickupTaskNumMat,pickupTaskBlockMaxNum);
                    end
                    break;
                else
                    continue;
                end
        end
    end
end

end