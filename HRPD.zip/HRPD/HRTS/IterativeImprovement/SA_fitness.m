function score = SA_fitness(x)
[schedule,TS,PS,TT,PT,TI,PI,TRe,PRe] = computeSchedule(x);
score = max(max(schedule+TRe));
end