function sequenceMat = TSDecoupled()
global TaskSet;
global TransportRobotSet;
global PickRobotSet;
global subtaskDistributionMat;
global blockWidthVec;
global subtaskIDCell;
global subtaskStationCell;
global subtaskPTimeMat;

m = size(TransportRobotSet,1);
n = size(PickRobotSet,1);

%% generate initial transport robot orders with minimized routing components
transportOrderMat = zeros(m,sum(blockWidthVec));
for i=1:m
    for j=1:sum(blockWidthVec)
        if ~isempty(subtaskIDCell{i,j})
            temp = subtaskIDCell{i,j};
            transportOrderMat(i,j)=temp(1,2);
        end
    end
end

%% generate pick robot orders

%%% start of initialization 
CurrentTime = zeros(m+n,1);
CurrentLocations = zeros(m+n,2);
for i=1:m
    CurrentLocations(i,:)=TransportRobotSet{i,1}.State;
end
for i=m+1:m+n
    CurrentLocations(i,:)=PickRobotSet{i-m,1}.State;
end

pickOrderMat = zeros(m,sum(blockWidthVec));
tempOrderMat = transportOrderMat;
% store unscheduled task indices
unscheduledTag = transportOrderMat~=0;
CurrentOrderVec = zeros(n,1);

%%% end of initialization 
while(any(any(unscheduledTag)))
%    disp(unscheduledTag);
    for j = 1:n
        maskMat = zeros(m,sum(blockWidthVec));
        
        if j == 1
            previous = 0;
        else
            previous = sum(blockWidthVec(1,1:j-1));
        end
        
        maskMat(:,previous+1:previous+blockWidthVec(1,j)) = tempOrderMat(:,previous+1:previous+blockWidthVec(1,j));
        
        vec = reshape(maskMat,m*sum(blockWidthVec),1);
        vec = vec(vec~= 0);
        if ~isempty(vec)
            minValue = min(vec);
            [rows,cols] = find(maskMat==minValue);
            colIndex = 0;
            rowIndex = 0;
            if length(cols)==1
                colIndex = cols(1,1);
                rowIndex = rows(1,1);
            else % multiple subtasks, using priority dispatching rules
                location1 = CurrentLocations(j,:);
                distVec = zeros(length(cols),1);
                for k=1:size(cols,1)
                    trid = rows(k,1);
                    location2 = subtaskStationCell{trid,cols(k,1)};
                    distVec(k,:) = getDistance(location1,location2);
                end
                
                [rr,cc] = find(distVec(:,1)==min(distVec(:,1)));
                bestIndex = rr(1,1);
                colIndex = cols(bestIndex,1);
                rowIndex = rows(bestIndex,1);
            end

            CurrentLocations(j,:) = subtaskStationCell{rowIndex,colIndex};
            CurrentOrderVec(j,1) = CurrentOrderVec(j,1)+1;
            pickOrderMat(rowIndex,colIndex) = CurrentOrderVec(j,1);
            tempOrderMat(rowIndex,colIndex) = 0;
            unscheduledTag(rowIndex,colIndex) = 0;                 
        else
            continue;
        end        
    end        
end

sequenceMat = order2sequence(transportOrderMat,pickOrderMat);
% [to,po]=sequence2order(sequenceMat,subtaskDistributionMat,blockWidthVec);
% isequal(to,transportOrderMat)
% isequal(po,pickOrderMat)

end