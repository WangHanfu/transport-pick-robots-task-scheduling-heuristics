function [sonCell,sonCount] = insert(partialSeqMat,r,c)

global subtaskDistributionMat;
global blockWidthVec;

if ~any(any(partialSeqMat))
    seqMat = partialSeqMat;
    seqMat(r,c) = 1;
    sonCell{1,1} = seqMat;
    sonCount = 1;
    return;
end

m = size(subtaskDistributionMat,1);
n = size(blockWidthVec,2);

transportID = r;
[pickID,~] = col2jk(c,blockWidthVec);

vec = partialSeqMat(transportID,:);
vec = vec(vec~=0);
tSize = length(vec);

col1 = jk2col(pickID,1,blockWidthVec);
col2 = jk2col(pickID,blockWidthVec(1,pickID),blockWidthVec);
mat = partialSeqMat(:,col1:col2);
mat = mat(mat~=0);
pSize = length(mat);

%% masked matrix
maskSeqMat = zeros(m,sum(blockWidthVec));
maskSeqMat(transportID,:) = partialSeqMat(transportID,:);
maskSeqMat(:,col1:col2) = partialSeqMat(:,col1:col2);

if ~any(any(maskSeqMat))
    seqMat = partialSeqMat;
    seqMat(r,c) = 1;
    sonCell{1,1} = seqMat;
    sonCount = 1;
    return;
end

sonCell = cell((tSize+1)*(pSize+1),1); %number of sons at most
sonCount = 1;

%% rule 1
seqMat = partialSeqMat;
successors = findSucc(seqMat,r,c);
for k=1:size(successors,1)
        seqMat(successors(k,1),successors(k,2)) = seqMat(successors(k,1),successors(k,2)) + 1;  
end
%seqMat(successors(:,1),successors(:,2)) = seqMat(successors(:,1),successors(:,2)) + 1;
seqMat(r,c) = 1;

sonCell{sonCount,1} = seqMat;
sonCount = sonCount + 1;

%% rule 2
totalRanks = unique(maskSeqMat(maskSeqMat~=0));
totalRanks = totalRanks';

for rank=totalRanks
    seqMat = partialSeqMat;
    seqMat(r,c) = rank;
    successors = findSucc(seqMat,r,c);
    for k=1:size(successors,1)
        seqMat(successors(k,1),successors(k,2)) = seqMat(successors(k,1),successors(k,2)) + 1;  
    end
    %seqMat(successors1(:,1),successors1(:,2)) = seqMat(successors1(:,1),successors1(:,2)) + 1;
    seqMat(r,c) = rank+1;
       
    sonCell{sonCount,1} = seqMat;
    sonCount = sonCount + 1;
end

%% rule 3

%% find disconnected subtasks
[rows,cols] = find(maskSeqMat~=0);

disconnectedMat = zeros(size(rows,1)^2,4);
k = 1;
for i=1:size(rows,1)
    RI = rows(i,1);
    CI = cols(i,1);
    
    succMat = findSucc(partialSeqMat,RI,CI);
    precMat = findPred(partialSeqMat,RI,CI);
    pathMat = [succMat;precMat];
    
    for j = i+1:size(rows,1)
        RJ = rows(j,1);
        CJ = cols(j,1);
        
        if (~ismember([RJ CJ],pathMat,'rows'))
            disconnectedMat(k,:) = [RI CI RJ CJ];
            k = k+1;
        end
    end
end

disconnectedMat(all(disconnectedMat==0,2),:) = [];

%%
if ~isempty(disconnectedMat)
    for i=1:size(disconnectedMat,1)
        RI = disconnectedMat(i,1);
        CI = disconnectedMat(i,2);
        RJ = disconnectedMat(i,3);
        CJ = disconnectedMat(i,4);
        
        rank1 = partialSeqMat(RI,CI);
        rank2 = partialSeqMat(RJ,CJ);
        if rank1 <= rank2
            seqMat = partialSeqMat;
                        
            successors = findSucc(seqMat,RI,CI);
            for k=1:size(successors,1)
                seqMat(successors(k,1),successors(k,2)) = seqMat(successors(k,1),successors(k,2)) + (rank2-rank1 + 2);  
            end
            %seqMat(successors(:,1),successors(:,2)) = seqMat(successors(:,1),successors(:,2)) + (rank2-rank1 + 2);
            seqMat(RI,CI) = rank2 + 2;  
            
            seqMat(r,c) = rank2;
            successors = findSucc(seqMat,r,c);
            for k=1:size(successors,1)
                seqMat(successors(k,1),successors(k,2)) = seqMat(successors(k,1),successors(k,2)) + 1;  
            end
            %seqMat(successors(:,1),successors(:,2)) = seqMat(successors(:,1),successors(:,2)) + 1;                                                                                            
            seqMat(r,c) = rank2+1;
                                     
            sonCell{sonCount,1} = seqMat;
            sonCount = sonCount + 1;
        end
        
        if rank1 >= rank2
            seqMat = partialSeqMat;
                        
            successors = findSucc(seqMat,RJ,CJ);
            for k=1:size(successors,1)
                seqMat(successors(k,1),successors(k,2)) = seqMat(successors(k,1),successors(k,2)) + (rank1-rank2 + 2);  
            end
            %seqMat(successors(:,1)',successors(:,2)') = seqMat(successors(:,1)',successors(:,2)') + (rank1-rank2 + 2);   
            seqMat(RJ,CJ) = rank1 + 2; 
            seqMat(r,c) = rank1; 
            
            successors = findSucc(seqMat,r,c);            
            for k=1:size(successors,1)
                seqMat(successors(k,1),successors(k,2)) = seqMat(successors(k,1),successors(k,2)) + 1;  
            end
            seqMat(r,c) = rank1+1;    
            
%             [TOMat,POMat]=sequence2order(seqMat,subtaskDistributionMat,blockWidthVec);
%             seqMat = order2sequence(TOMat,POMat,subtaskDistributionMat,blockWidthVec);
%             
            sonCell{sonCount,1} = seqMat;
            sonCount = sonCount + 1;
        end
        
    end
end

sonCount = sonCount - 1;

end

