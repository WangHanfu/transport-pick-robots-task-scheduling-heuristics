function selectMat = perfectMatchingMax(latestTimeVec,latestStationMat,unscheduledTag,objectiveSelect)

global TaskSet;
global TransportRobotSet;
global PickRobotSet;
global subtaskDistributionMat;
global blockWidthVec;
global subtaskIDCell;
global subtaskStationCell;
global subtaskPTimeMat;

m = size(subtaskPTimeMat,1);
n = size(blockWidthVec,2);
Csum = sum(blockWidthVec);

[rows,cols] = find(unscheduledTag == 1);
num = size(rows,1);

varlen = num+1;
M=10000;
Aineq=[];
bineq=[];

%constraint (1)
A=[M*eye(num),-ones(num,1)];
b=zeros(num,1);
for i=1:num
    r = rows(i,1);
    c = cols(i,1);
    transportID = r;
    b(i,1) = M - subtaskPTimeMat(r,c)- getDistance(subtaskStationCell{r,c},latestStationMat(transportID,:)) -latestTimeVec(transportID,1);
end

Aineq=[Aineq;A];
bineq=[bineq;b];

%constraint (2)
A=[M*eye(num),-ones(num,1)];
b=zeros(num,1);
for i=1:num
    r = rows(i,1);
    c = cols(i,1);
    [pickID,~] = col2jk(c,blockWidthVec);
    b(i,1) = M - subtaskPTimeMat(r,c) - getDistance(subtaskStationCell{r,c},latestStationMat(m+pickID,:)) -latestTimeVec(m+pickID,:);
end

Aineq=[Aineq;A];
bineq=[bineq;b];

%constraint (3)
A=zeros(m,varlen);
b=zeros(m,1);
for i=1:m
    [indices,~] = find(rows==i);
    if ~isempty(indices)
        vec=zeros(1,varlen);
        vec(1,indices)=1;
        A(i,:)=vec;
        b(i,1)=1;
    end
end

Aineq=[Aineq;A];
bineq=[bineq;b];

%constraint (4)
pickIDList = zeros(num,1);
for i=1:num
    [pickIDList(i,1),~] = col2jk(cols(i,1),blockWidthVec);
end

A=zeros(n,varlen);
b=zeros(n,1);
for i=1:n
    [indices,~] = find(pickIDList==i);
    if ~isempty(indices)
        vec=zeros(1,varlen);
        vec(1,indices)=1;
        A(i,:)=vec;
        b(i,1)=1;
    end
end

Aineq=[Aineq;A];
bineq=[bineq;b];

%constraint (5)
unfinishedTransportNum = length(unique(rows));
unfinishedPickNum = length(unique(pickIDList));
A=zeros(1,varlen);
A(1,1:num)=1;
b=min(unfinishedTransportNum,unfinishedPickNum);

Aeq=A;
tempbeq=b;

%% variable bounds

intcon=1:num;
lb = zeros(varlen,1);
ub = inf(varlen,1);
ub(1:num,1)=1;
%% Objective
f=zeros(varlen,1);
f(end,1) = 1;
%% MILP

for beq = tempbeq:-1:1
    opts = optimoptions('intlinprog','Display','none','Heuristics','round-diving','IPPreprocess','none','MaxTime',60);
    [bestSolution,fval,exitflag,output] = intlinprog(f,intcon,Aineq,bineq,Aeq,beq,lb,ub,opts);
    if ~isempty(bestSolution)
        outputSelect=bestSolution(1:num,1);
        outputSelect=int32(outputSelect);
        selectMat = zeros(m,Csum);
        for i=1:num
            if outputSelect(i,1) == 1
                selectMat(rows(i,1),cols(i,1)) = 1;
            end
        end
        break;
    else
%         disp(blockWidthVec);
%         disp(unscheduledTag);
    end
end


end

