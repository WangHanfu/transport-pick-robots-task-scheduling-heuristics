function outMat = insertOrder(selectPDR)
% selectPDR: select priority dispathing rule
global TaskSet;
global TransportRobotSet;
global PickRobotSet;
global subtaskDistributionMat;
global blockWidthVec;
global subtaskIDCell;
global subtaskStationCell;
global subtaskPTimeMat;

m = size(TransportRobotSet,1);
n = size(PickRobotSet,1);

% 1: minMax
% 2: minSum

%% start of initialization
CurrentTime = zeros(m+n,1);
CurrentLocations = zeros(m+n,2);
for i=1:m
    CurrentLocations(i,:)=TransportRobotSet{i,1}.State;
end
for i=m+1:m+n
    CurrentLocations(i,:)=PickRobotSet{i-m,1}.State;
end

robotOrders = ones(m+n,1);

% store unscheduled task indices
unscheduledTag = subtaskPTimeMat~=0;

transportOrderMat = zeros(m,sum(blockWidthVec));
pickOrderMat = zeros(m,sum(blockWidthVec));
outMat = zeros(m,sum(blockWidthVec));
k=1;
%%% end of initialization
while(any(any(unscheduledTag)))
%     switch selectPDR
%         case 1
%             selectMat = myAppend(CurrentTime,CurrentLocations,unscheduledTag,selectPDR);
%         case 2
%             selectMat = myAppend(CurrentTime,CurrentLocations,unscheduledTag,selectPDR);
%         case 3
%             selectMat = myAppend(CurrentTime,CurrentLocations,unscheduledTag,selectPDR);
%         case 4
%             selectMat = myAppend(CurrentTime,CurrentLocations,unscheduledTag,selectPDR);
%     end
    
    switch selectPDR
        case 1
            [r,c] = myAppend(CurrentTime,CurrentLocations,unscheduledTag,selectPDR);
        case 2
            [r,c] = myAppend(CurrentTime,CurrentLocations,unscheduledTag,selectPDR);
        case 3
            [r,c] = myAppend(CurrentTime,CurrentLocations,unscheduledTag,selectPDR);
        case 4
            [r,c] = myAppend(CurrentTime,CurrentLocations,unscheduledTag,selectPDR);
    end

    transportID = r;
    [pickID,~] = col2jk(c,blockWidthVec);
    
    transportOrderMat(r,c) = robotOrders(transportID,1);
    robotOrders(transportID,1) = robotOrders(transportID,1)+1;
    pickOrderMat(r,c) = robotOrders(pickID+m,1);
    robotOrders(pickID+m,1) = robotOrders(pickID+m,1) +1;
    
    outMat(r,c) = k;
    k = k+1;
    unscheduledTag(r,c) = 0;
        
    time1 = CurrentTime(transportID,1)+getDistance(subtaskStationCell{r,c},CurrentLocations(transportID,:));
    time2 = CurrentTime(m+pickID,1)+getDistance(subtaskStationCell{r,c},CurrentLocations(m+pickID,:));
    CurrentTime(transportID,1) = max(time1,time2)+subtaskPTimeMat(r,c);
    CurrentTime(m+pickID,1) = max(time1,time2)+subtaskPTimeMat(r,c);
    CurrentLocations(transportID,:) = subtaskStationCell{r,c};
    CurrentLocations(m+pickID,:) = subtaskStationCell{r,c};
    
end

end