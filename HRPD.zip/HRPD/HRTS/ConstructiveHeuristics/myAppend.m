function [appendR,appendC] = myAppend(latestTimeVec,latestStationMat,unscheduledTag,selectPDR)
% global TaskSet;
% global TransportRobotSet;
% global PickRobotSet;
% global subtaskDistributionMat;
% global subtaskIDCell;

global blockWidthVec;
global subtaskStationCell;
global subtaskPTimeMat;

m = size(subtaskPTimeMat,1);
n = size(blockWidthVec,2);
Csum = sum(blockWidthVec);

[rows,cols] = find(unscheduledTag == 1);
num = size(rows,1);
headVec =zeros(num,4);

for i=1:num
    r = rows(i,1);
    c = cols(i,1);
    transportID = r;
    [pickID,~] = col2jk(c,blockWidthVec);
    t1 = latestTimeVec(transportID,1) + getDistance(subtaskStationCell{r,c},latestStationMat(transportID,:)) ;
    t2 = latestTimeVec(m+pickID,:) + getDistance(subtaskStationCell{r,c},latestStationMat(m+pickID,:)) ;
    headVec(i,:) = [max(t1,t2),t1,t2,subtaskPTimeMat(r,c)];
end

minHead = min(headVec(:,1));

[minHeadIndices,~] = find(headVec(:,1) == minHead);
sizeOfMultiple = size(minHeadIndices,1);
if sizeOfMultiple == 1
    minIndex = minHeadIndices(1,1);
else
    switch selectPDR
        case 1 %shortest time difference
            vec = zeros(num,1);
            for j = minHeadIndices
                vec(j,1) = abs(headVec(j,2) - headVec(j,3) );
            end
            
            vec2 = vec(vec~=0);
            if isempty(vec2)
                minIndex = minHeadIndices(1,1);
            else
                [rs,~] = find(vec == min(vec2));
                minIndex = rs(1,1);
            end
                                    
        case 2 %longest time difference
            vec = zeros(num,1);
            for j = minHeadIndices
                vec(j,1) = abs(headVec(j,2) - headVec(j,3) );
            end
            
            vec2 = vec(vec~=0);
            
            if isempty(vec2)
                minIndex = minHeadIndices(1,1);
            else
                [rs,~] = find(vec == max(vec2));
                minIndex = rs(1,1);
            end
            
        case 3 %shortest processing time
            vec = zeros(num,1);
            for j = minHeadIndices
                vec(j,1) = headVec(j,4);
            end
            
            vec2 = vec(vec~=0);
            if isempty(vec2)
                minIndex = minHeadIndices(1,1);
            else
                [rs,~] = find(vec == min(vec2));
                minIndex = rs(1,1);
            end
        case 4 %longest processing time
            vec = zeros(num,1);
            for j = minHeadIndices
                vec(j,1) = headVec(j,4);
            end
            
            vec2 = vec(vec~=0);
            if isempty(vec2)
                minIndex = minHeadIndices(1,1);
            else
                [rs,~] = find(vec == max(vec2));
                minIndex = rs(1,1);
            end
    end
        
end

appendR = rows(minIndex,1);
appendC = cols(minIndex,1);

end

