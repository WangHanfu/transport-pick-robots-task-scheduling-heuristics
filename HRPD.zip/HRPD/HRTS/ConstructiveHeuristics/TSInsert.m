function partialSeqMat = TSInsert(selectObjective)

global TaskSet;
global TransportRobotSet;
global PickRobotSet;
global subtaskDistributionMat;
global blockWidthVec;
global subtaskIDCell;
global subtaskStationCell;
global subtaskPTimeMat;

m = size(TransportRobotSet,1);
n = size(PickRobotSet,1);

% 1: minMax
% 2: minSum
% 3: minDiff
[subtaskDistributionMat,blockWidthVec,subtaskIDCell,subtaskStationCell,subtaskPTimeMat] = problem2matrices(TaskSet,m,n);

partialSeqMat = zeros(m,sum(blockWidthVec));
% store unscheduled task indices
unscheduledTag = subtaskPTimeMat~=0;
insertOrderMat = insertOrder(1);
temp = 1;
%%% end of initialization
while(any(any(unscheduledTag)))
    [r,c] = find(insertOrderMat == temp);
    %fprintf("r=%d,c=%d\n",r,c);
    temp = temp + 1;
    unscheduledTag(r,c) = 0;
    switch selectObjective
        case 1
            [sonCell,sonCount] = insert(partialSeqMat,r,c);
        case 2
    end
    
    minValue = 10000;
    minMat = [];
    for i=1:sonCount
        son = sonCell{i,1};
        [schedule,TS,PS,TT,PT,TI,PI,TRe,PRe] = computeSchedule(partialSeqMat);
        makespan = max(max(schedule+TRe));
        if makespan<minValue
            minMat = son;
            minValue = makespan;
        end
    end
       
    partialSeqMat = minMat;
end

end