function sequenceMat = TS3Matching(selectObjective)

global TaskSet;
global TransportRobotSet;
global PickRobotSet;
global subtaskDistributionMat;
global blockWidthVec;
global subtaskIDCell;
global subtaskStationCell;
global subtaskPTimeMat;

m = size(TransportRobotSet,1);
n = size(PickRobotSet,1);

% 1: minMax
% 2: minSum
% 3: minDiff

%% generate initial transport robot orders with minimized routing components
transportOrderMat = zeros(m,sum(blockWidthVec));
for i=1:m
    for j=1:sum(blockWidthVec)
        if ~isempty(subtaskIDCell{i,j})
            temp = subtaskIDCell{i,j};
            transportOrderMat(i,j)=temp(1,2);
        end
    end
end

%% generate sequence

%%% start of initialization 
CurrentTime = zeros(m+n,1);
CurrentLocations = zeros(m+n,2);
for i=1:m
    CurrentLocations(i,:)=TransportRobotSet{i,1}.State;
end
for i=m+1:m+n
    CurrentLocations(i,:)=PickRobotSet{i-m,1}.State;
end

sequenceMat = zeros(m,sum(blockWidthVec));
% store unscheduled task indices
unscheduledTag = transportOrderMat~=0;

rank = 1;
%%% end of initialization 
while(any(any(unscheduledTag)))
    switch selectObjective
        case 1
        	selectMat = perfectMatchingMax(CurrentTime,CurrentLocations,unscheduledTag,1);
        case 2
            selectMat = perfectMatchingSum(CurrentTime,CurrentLocations,unscheduledTag,1);
    end
        
    sequenceMat(selectMat==1) = rank;
    unscheduledTag(selectMat==1) = 0;
    rank = rank + 1;
    
    [rows,cols] = find(selectMat == 1);
    for i=1:size(rows,1)
        r = rows(i,1);
        c = cols(i,1);
        
        transportID = r;
        [pickID,~] = col2jk(c,blockWidthVec);
        
        time1 = CurrentTime(transportID,1)+getDistance(subtaskStationCell{r,c},CurrentLocations(transportID,:));
        time2 = CurrentTime(m+pickID,1)+getDistance(subtaskStationCell{r,c},CurrentLocations(m+pickID,:));
        CurrentTime(transportID,1) = max(time1,time2)+subtaskPTimeMat(r,c);
        CurrentTime(m+pickID,1) = max(time1,time2)+subtaskPTimeMat(r,c);
        CurrentLocations(transportID,:) = subtaskStationCell{r,c};
        CurrentLocations(m+pickID,:) = subtaskStationCell{r,c};
    end
end

end