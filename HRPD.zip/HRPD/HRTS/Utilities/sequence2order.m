function  [transportOrderMat,pickOrderMat]= sequence2order(sequenceMat)
%Computing of TO and PO from Sequence

global subtaskDistributionMat;
global blockWidthVec;

[m,n] = size(subtaskDistributionMat);
transportOrderMat = zeros(m,sum(blockWidthVec));
pickOrderMat = zeros(m,sum(blockWidthVec));

transportRanks = ones(m,1);
pickRanks = ones(1,n);

for i=1:max(max(sequenceMat))
    [rows,cols]=find(sequenceMat==i);
    if ~isempty(rows)
        for j=1:size(rows,1)
            r = rows(j,1);
            c = cols(j,1);
            transportOrderMat(r,c) = transportRanks(r,1);
            transportRanks(r,1) = transportRanks(r,1)+1;
            
            [pickID,~] = col2jk(c,blockWidthVec);
                        
            pickOrderMat(r,c) = pickRanks(1,pickID);
            pickRanks(1,pickID) = pickRanks(1,pickID) + 1;
            
        end
    end
        
end

end
