function [j,k] = col2jk(c,blockWidthVec)

n = size(blockWidthVec,2);
pickID = 0;
colSum1 = 0;
colSum2 = 0;
for iter=1:n
    colSum1 = colSum2;
    colSum2 = colSum2 + blockWidthVec(1,iter);
    if c>colSum1 && c<=colSum2
        pickID = iter;
        break;
    end
end
j = pickID;

if j == 1
    k = c;
else
    k = c-sum(blockWidthVec(1,1:j-1));
end

end

