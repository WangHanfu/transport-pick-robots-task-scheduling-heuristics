function sonMat = findSucc(partialSeqMat,r,c)

global subtaskDistributionMat;
global blockWidthVec;

m = size(subtaskDistributionMat,1);
n = size(blockWidthVec,2);

subtaskFlag = partialSeqMat ~= 0;
queue = zeros(sum(sum(subtaskFlag)),3);
queue(1,:) = [r,c,0]; %

headIndex = 0;
numOfSon = 1;

while( headIndex~=numOfSon )
    headIndex = headIndex + 1;
    head = queue(headIndex,:);
    queue(headIndex,3) = 1;
    
    rr = head(1,1);
    cc = head(1,2);
        
    transportID = rr;
    [pickID,~] = col2jk(cc,blockWidthVec);
    maskSeqMat = zeros(m,sum(blockWidthVec));
    maskSeqMat(transportID,:) = partialSeqMat(transportID,:);
    col1 = jk2col(pickID,1,blockWidthVec);
    col2 = jk2col(pickID,blockWidthVec(1,pickID),blockWidthVec);
    maskSeqMat(:,col1:col2) = partialSeqMat(:,col1:col2);
        
    [rows,cols] = find(maskSeqMat == partialSeqMat(rr,cc)+1 );
    if ~isempty(rows)
        sizeSon = size(rows,1);
        queue(numOfSon+1:numOfSon+sizeSon,1) = rows;
        queue(numOfSon+1:numOfSon+sizeSon,2) = cols;
        queue(numOfSon+1:numOfSon+sizeSon,3) = 0;

        numOfSon = numOfSon + sizeSon;            
    end    
end
queue(1,:) = [];
sonMat = queue(:,1:2);
sonMat(all(sonMat==0,2),:) = [];
sonMat = unique(sonMat,'rows');

end

