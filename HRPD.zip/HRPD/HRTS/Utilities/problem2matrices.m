function [subtaskDistributionMat,blockWidthVec,subtaskIDCell,subtaskStationCell,subtaskPTimeMat] = problem2matrices(TaskSet,m,n)

subtaskDistributionMat = zeros(m,n);
subtaskDistributionIDCell = cell(m,n);
for i=1:size(TaskSet,1)
    task = TaskSet{i,1};
    pickupSubtasks = task.PickupSubtaskMat;
    for j=1:size(pickupSubtasks,1)
        task = pickupSubtasks(j,:);
        trid = task(1,3);
        prid = task(1,4);
        subtaskDistributionMat(trid,prid) = subtaskDistributionMat(trid,prid)+1;
        subtaskDistributionIDCell{trid,prid} = [subtaskDistributionIDCell{trid,prid};task(1,1:2)];        
    end
end

blockWidthVec = zeros(1,n);
for j=1:n
    blockWidthVec(1,j)=max(subtaskDistributionMat(:,j));
end

subtaskIDCell = cell(m,sum(blockWidthVec));
subtaskStationCell = cell(m,sum(blockWidthVec));
subtaskPTimeMat = zeros(m,sum(blockWidthVec));

for i=1:m
    tempSum = 0;
    for j=1:n
        if subtaskDistributionMat(i,j)~=0
            mat = subtaskDistributionIDCell{i,j};
            for k = 1:subtaskDistributionMat(i,j)
                id = mat(k,:);
                subtaskIDCell{i,tempSum + k} = id;
                task = TaskSet{id(1,1),1};
                pickupSubtasks = task.PickupSubtaskMat;
                task = pickupSubtasks(id(1,2),:);
                subtaskStationCell{i,tempSum + k} = task(1,6:7);
                subtaskPTimeMat(i,tempSum + k) = task(1,8);
            end                        
        end
        tempSum = tempSum + blockWidthVec(1,j);
    end    
end

end