function sequenceMat = order2sequence(transportOrderMat,pickOrderMat)
%Computing Sequence from TO and PO

global subtaskDistributionMat;
global blockWidthVec;

[m,n] = size(subtaskDistributionMat);
sequenceMat = zeros(m,sum(blockWidthVec));
totalTaskSum=sum(sum(subtaskDistributionMat));
r=0;
while (totalTaskSum>0)
    r=r+1;
    [rows,cols] = find(and(transportOrderMat==1,pickOrderMat==1)==1); 
    if isempty(rows)
        sequenceMat = [];
        break; %cyclic, infeasible
    else
        sourceNum = size(rows,1);
        for i=1:sourceNum
            sequenceMat(rows(i,1),cols(i,1)) = r;
            transportOrderMat(rows(i,1),:) = transportOrderMat(rows(i,1),:) - 1;% row ranks should minus 1.
            cIndex = cols(i,1); % all column blocks' ranks should minus 1.
            
            [pickID,~] = col2jk(cIndex,blockWidthVec);
            
            if pickID == 1
                formerBlockNum = 0;
            else
                formerBlockNum = sum(blockWidthVec(1,1:pickID-1));
            end
            
            pickOrderMat(:,formerBlockNum+1:formerBlockNum+blockWidthVec(1,pickID)) = pickOrderMat(:,formerBlockNum+1:formerBlockNum+blockWidthVec(1,pickID)) - 1;
        end
        
        totalTaskSum = totalTaskSum - sourceNum;
    end
end
end %end of function