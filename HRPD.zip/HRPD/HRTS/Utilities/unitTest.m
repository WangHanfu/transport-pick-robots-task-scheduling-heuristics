clc;
clear;
load("WarehouseMap.mat");

m=3;
n=4;
mapSize = 10;

%% initialize

ColorMat = rand(m,3);

transportOrder = [1 5 2 4 0 3;1 3 0 0 0 2;0 3 5 4 1 2];
pickOrder = [1 5 1 3 0 2;2 4 0 0 0 3;0 2 3 2 1 1];

subtaskDistributionMat = [1 2 1 1;1 1 0 1;0 2 2 1];
blockWidthVec = [1 2 2 1];
subtaskPTimeMat = randi([3,7],m,sum(blockWidthVec));
subtaskPTimeMat(pickOrder == 0) = 0;

subtaskStationCell = cell(m,sum(blockWidthVec));
for i=1:m
    for j=1:sum(blockWidthVec)
        if subtaskPTimeMat(i,j)~=0
            subtaskStationCell{i,j} = randi([1 mapSize],1,2);
        end
    end
end

RobotSet = cell(m+n,1);
for i=1:m+n
    RobotSet{i,1} = ClassRobot;
    RobotSet{i,1}.State = [1  1];
end

%% test order2sequence and sequence2order
sequenceMat = order2sequence(transportOrder,pickOrder,subtaskDistributionMat,blockWidthVec);
[to,po]=sequence2order(sequenceMat,subtaskDistributionMat,blockWidthVec);
isequal(to,transportOrder)
isequal(po,pickOrder)

%% test computeSchedule
[schedule,TS,PS,TT,PT,TI,PI,TRe,PRe] = computeSchedule(sequenceMat,subtaskStationCell,subtaskPTimeMat,RobotSet,subtaskDistributionMat,blockWidthVec,WarehouseMap);
[HA,TA] = computeHeadTail(sequenceMat,subtaskStationCell,subtaskPTimeMat,RobotSet,subtaskDistributionMat,blockWidthVec,WarehouseMap);

schedule+TRe
TRe
makespan = max(max(schedule+TRe))

HA+TA+subtaskPTimeMat

plotGantt(sequenceMat,schedule,TS,PS,TT,PT,TI,PI,TRe,PRe,subtaskDistributionMat,blockWidthVec,ColorMat);

%% test reverse schedule
reverseSequence = sequenceMat;
maxRank = max(max(sequenceMat));
for i=1:maxRank
    [r,c]=find(sequenceMat==i);
    for j=1:size(r,1)
        reverseSequence(r(j,1),c(j,1))=maxRank-i+1;
    end
end

[reverseSchedule,rTS,rPS,rTT,rPT,rTI,rPI,rTRe,rPRe] = computeSchedule(reverseSequence,subtaskStationCell,subtaskPTimeMat,RobotSet,subtaskDistributionMat,blockWidthVec,WarehouseMap);
reverseMakespan = max(max(reverseSchedule+rTRe));
isequal(reverseMakespan,makespan);
figure(2);
plotGantt(reverseSequence,reverseSchedule,rTS,rPS,rTT,rPT,rTI,rPI,rTRe,rPRe,subtaskDistributionMat,blockWidthVec,ColorMat);
