function [schedule,TS,PS,TT,PT,TI,PI,TRe,PRe] = computeSchedule(sequenceMat)
%compute semi-active task schedule for transport robots and pick robots
%schedule: subtask completion times, semi-active
%TS:transport robot start time
%PS:pick robot start time
%TT:transport robot travel duration
%PT:pick robot travel duration
%TI:transport robot idle duration
%PI:pick robot idle duration
%TRe:transport robot return duration
%PRe:pick robot return duration

global TaskSet;
global TransportRobotSet;
global PickRobotSet;
global subtaskDistributionMat;
global blockWidthVec;
global subtaskIDCell;
global subtaskStationCell;
global subtaskPTimeMat;

[m,n]=size(subtaskDistributionMat);
schedule = zeros(m,sum(blockWidthVec));

TS = zeros(m,sum(blockWidthVec));
PS = zeros(m,sum(blockWidthVec));
TT = zeros(m,sum(blockWidthVec));
PT = zeros(m,sum(blockWidthVec));
TI = zeros(m,sum(blockWidthVec));
PI = zeros(m,sum(blockWidthVec));
TRe = zeros(m,sum(blockWidthVec));
PRe = zeros(m,sum(blockWidthVec));

%% keep record robots' latest time and space locations
LatestTime=zeros(m+n,1);
LatestLocations=zeros(m+n,2);
for i=1:m+n
    if i<=m
        LatestLocations(i,:)=TransportRobotSet{i,1}.State;
    else
        LatestLocations(i,:)=PickRobotSet{i-m,1}.State;
    end
end

maxRank = max(max(sequenceMat));
for rank = 1:maxRank
    [rows,cols]=find(sequenceMat==rank);
    if ~isempty(rows)
        for j=1:size(rows,1)
            r = rows(j,1);
            c = cols(j,1);
            
            transportID = r;
            [pickID,~] = col2jk(c,blockWidthVec);
            
            TS(r,c) = LatestTime(transportID,1);
            PS(r,c) = LatestTime(m+pickID,1);
            
            TT(r,c) = getDistance(LatestLocations(transportID,:),subtaskStationCell{r,c});
            PT(r,c) = getDistance(LatestLocations(m+pickID,:),subtaskStationCell{r,c});
            
            transportArriveTime = TS(r,c)+TT(r,c);            
            pickArriveTime = PS(r,c)+PT(r,c);
            meetTime = max(transportArriveTime,pickArriveTime);
            
            TI(r,c) = meetTime-transportArriveTime;
            PI(r,c) = meetTime-pickArriveTime;
                        
            finishTime = meetTime+subtaskPTimeMat(r,c);
            schedule(r,c) = finishTime;
            
            LatestTime(transportID,1)=finishTime;
            LatestTime(m+pickID,1) = finishTime;
            
            LatestLocations(transportID,:) = subtaskStationCell{r,c};             
            LatestLocations(m+pickID,:) = subtaskStationCell{r,c};
                                                
            if rank == max(sequenceMat(transportID,:))
                TRe(r,c) = getDistance(LatestLocations(transportID,:),TransportRobotSet{transportID,1}.State);
                %%%%%%%%此处注意修改
            end            
        end
                
    end    
end



end