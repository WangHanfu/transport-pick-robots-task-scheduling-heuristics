function  partialSequenceCell = insertSubtask(partialSequenceMat,subtaskDistributionMat,blockWidthVec,subtaskRC)
%Computing of PO and TO from Sequence

[m,n] = size(subtaskDistributionMat);
pickOrderMat = zeros(m,sum(blockWidthVec));
transportOrderMat = zeros(m,sum(blockWidthVec));

pickRanks = ones(m,1);
transportRanks = ones(1,n);

for i=1:max(max(partialSequenceMat))
    [rows,cols]=find(partialSequenceMat==i);
    if ~isempty(rows)
        for j=1:size(rows,1)
            r = rows(j,1);
            c = cols(j,1);
            pickOrderMat(r,c) = pickRanks(r,1);
            pickRanks(r,1) = pickRanks(r,1)+1;
                        
            transportID = 0;
            colSum1 = 0;
            colSum2 = 0;
            for k=1:n
                colSum1 = colSum2;
                colSum2 = colSum2 + blockWidthVec(1,k);
                if c>colSum1 && c<=colSum2
                    transportID = k;
                    break;
                end                
            end
                        
            transportOrderMat(r,c) = transportRanks(1,transportID);
            transportRanks(1,transportID) = transportRanks(1,transportID) + 1;
            
        end
    end
        
end

end
