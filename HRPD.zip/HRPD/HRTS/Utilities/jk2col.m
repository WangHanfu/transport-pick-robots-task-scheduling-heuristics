function col = jk2col(j,k,blockWidthVec)

if j==1
    col = k;
else
    col = sum(blockWidthVec(1,1:j-1))+k;
end

end

