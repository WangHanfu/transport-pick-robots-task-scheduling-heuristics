function [StationSequence,minValue] = TSPOptimization(Stations,depot)
n=size(Stations,1);
distanceMat=zeros(n);
for i=1:n
    for j=1:i
        distanceMat(i,j)=getDistance(Stations(i,:),Stations(j,:));
        distanceMat(j,i)=distanceMat(i,j);
    end
end

FitnessFcn = @(x) traveling_salesman_fitness(x,distanceMat,Stations,depot);
my_plot = @(options,state,flag) traveling_salesman_plot(options, ...
    state,flag,Stations);
options = optimoptions(@ga, 'PopulationType', 'custom','InitialPopulationRange',[1;50]);
% options = optimoptions(options,'CreationFcn',@create_permutations,'CrossoverFcn',@crossover_permutation,'MutationFcn',@mutate_permutation, ...
%     'PlotFcn', my_plot,  'MaxGenerations',100,'PopulationSize',50,'MaxStallGenerations',20,'UseVectorized',true);
options = optimoptions(options,'CreationFcn',@create_permutations,'CrossoverFcn',@crossover_permutation,'MutationFcn',@mutate_permutation, ...
    'MaxGenerations',50,'PopulationSize',50,'MaxStallGenerations',10,'UseVectorized',true);
numberOfVariables = n;
[order,minValue,~,~] = ga(FitnessFcn,numberOfVariables,[],[],[],[],[],[],[],options);
StationSequence = int8(cell2mat(order));
end

function pop = create_permutations(NVARS,~,options)
totalPopulationSize = sum(options.PopulationSize);
n = NVARS;
pop = cell(totalPopulationSize,1);
for i = 1:totalPopulationSize
    pop{i} = randperm(n);
end
end

function xoverKids  = crossover_permutation(parents,~,~,~,~,thisPopulation)
nKids = length(parents)/2;
xoverKids = cell(nKids,1); % Normally zeros(nKids,NVARS);
index = 1;

for i=1:nKids
    % here is where the special knowledge that the population is a cell
    % array is used. Normally, this would be thisPopulation(parents(index),:);
    parent = thisPopulation{parents(index)};
    index = index + 2;
    
    % Flip a section of parent1.
    p1 = ceil((length(parent) -1) * rand);
    p2 = p1 + ceil((length(parent) - p1- 1) * rand);
    child = parent;
    child(p1:p2) = fliplr(child(p1:p2));
    xoverKids{i} = child; % Normally, xoverKids(i,:);
end
end

function mutationChildren = mutate_permutation(parents ,~,~,~, ~, ~,thisPopulation,~)
mutationChildren = cell(length(parents),1);% Normally zeros(length(parents),NVARS);
for i=1:length(parents)
    parent = thisPopulation{parents(i)}; % Normally thisPopulation(parents(i),:)
    p = ceil(length(parent) * rand(1,2));
    child = parent;
    child(p(1)) = parent(p(2));
    child(p(2)) = parent(p(1));
    mutationChildren{i} = child; % Normally mutationChildren(i,:)
end
end

function state = traveling_salesman_plot(~,state,flag,locations)
persistent x y
if strcmpi(flag,'init')
    load('usborder.mat','x','y','xx','yy');
end
plot(x,y,'Color','red');
%  axis ij;
axis([0 112 0 280]);

hold on;
[~,i] = min(state.Score);
genotype = state.Population{i};

plot(locations(:,1),locations(:,2),'bo');
plot(locations(genotype,1),locations(genotype,2));
hold off
end

function scores = traveling_salesman_fitness(x,distancesMatrix,locations,depot)
scores = zeros(size(x,1),1);
for j = 1:size(x,1)
    % here is where the special knowledge that the population is a cell
    % array is used. Normally, this would be pop(j,:);
    p = x{j};
    xFirst = locations(p(1),1);
    yFirst = locations(p(1),2);
    xLast = locations(p(end),1);
    yLast = locations(p(end),2);
    
    d4 = getDistance(depot,locations(p(1),:))+getDistance(depot,locations(p(end),:));
    f = d4;
    for i = 2:length(p)
        f = f + distancesMatrix(p(i-1),p(i));
    end
    scores(j) = f;
end
end
