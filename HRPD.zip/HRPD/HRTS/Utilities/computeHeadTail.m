function [HA,TA] = computeHeadTail(sequenceMat)
%compute semi-active task schedule for transport robots and pick robots

global TaskSet;
global TransportRobotSet;
global PickRobotSet;
global subtaskDistributionMat;
global blockWidthVec;
global subtaskIDCell;
global subtaskStationCell;
global subtaskPTimeMat;

[m,n]=size(subtaskDistributionMat);
schedule = zeros(m,sum(blockWidthVec));

HA = zeros(m,sum(blockWidthVec));
TA = zeros(m,sum(blockWidthVec));

%% keep record robots' latest time and space locations
LatestTime=zeros(m+n,1);
LatestLocations=zeros(m+n,2);
for i=1:m+n
    if i<=m
        LatestLocations(i,:)=TransportRobotSet{i,1}.State;
    else
        LatestLocations(i,:)=PickRobotSet{i-m,1}.State;
    end
end

BackTime=zeros(m+n,1);
BackLocations=zeros(m+n,2);
for i=1:m+n
    if i<=m
        BackLocations(i,:)=TransportRobotSet{i,1}.State;
    else
        BackLocations(i,:)=PickRobotSet{i-m,1}.State;
    end
end

maxRank = max(max(sequenceMat));
for i = 1:maxRank
    %% HEAD
    [rows,cols]=find(sequenceMat==i);
    if ~isempty(rows)
        for j=1:size(rows,1)
            r = rows(j,1);
            c = cols(j,1);
            
            transportID = r;
            [pickID,~] = col2jk(c,blockWidthVec);
            
            transportArriveTime = LatestTime(transportID,1)+getDistance(LatestLocations(transportID,:),subtaskStationCell{r,c});
            pickArriveTime = LatestTime(m+pickID,1)+getDistance(LatestLocations(m+pickID,:),subtaskStationCell{r,c});
            meetTime = max(transportArriveTime,pickArriveTime);
            
            HA(r,c) = meetTime;
            
            finishTime = meetTime+subtaskPTimeMat(r,c);
            
            LatestTime(transportID,1)=finishTime;
            LatestTime(m+pickID,1) = finishTime;
            
            LatestLocations(transportID,:) = subtaskStationCell{r,c};
            LatestLocations(m+pickID,:) = subtaskStationCell{r,c};
        end
    end
    
    %% TAIL
    [rows,cols]=find(sequenceMat==maxRank-i+1);
    if ~isempty(rows)
        for j=1:size(rows,1)
            r = rows(j,1);
            c = cols(j,1);
            
            transportID = r;
            [pickID,~] = col2jk(c,blockWidthVec);
            
            transportArriveTime = BackTime(transportID,1)+getDistance(BackLocations(transportID,:),subtaskStationCell{r,c});
            pickArriveTime = BackTime(m+pickID,1)+getDistance(BackLocations(m+pickID,:),subtaskStationCell{r,c});
            meetTime = max(transportArriveTime,pickArriveTime);
            
            TA(r,c) = meetTime;
            
            finishTime = meetTime+subtaskPTimeMat(r,c);
            
            BackTime(transportID,1)=finishTime;
            BackTime(m+pickID,1) = finishTime;
            
            BackLocations(transportID,:) = subtaskStationCell{r,c};
            BackLocations(m+pickID,:) = subtaskStationCell{r,c};
        end
    end
    
end



end