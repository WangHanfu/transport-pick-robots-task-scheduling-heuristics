clc;
clear;

m=3;
n=3;

subtaskDistributionMat = ones(m,n);
blockWidthVec = ones(1,n);

A=[2 0 1;1 4 3;3 1 2];

% [to,po]=sequence2order(A,subtaskDistributionMat,blockWidthVec);
% sequenceMat = order2sequence(to,po,subtaskDistributionMat,blockWidthVec);
% isequal(A,sequenceMat)
sb = insert(A,1,2,subtaskDistributionMat,blockWidthVec);
A=[1 0 2 3;2 3 0 4;0 0 1 0];
sb = insert(A,2,3,ones(3,4),ones(1,4));
