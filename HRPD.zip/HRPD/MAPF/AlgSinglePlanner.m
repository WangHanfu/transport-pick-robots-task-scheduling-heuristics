function path = AlgSinglePlanner(mapGrid,startState,goalState,ctime,constraints)
    [height,~]=size(mapGrid);
    xy2rc=@(x,y)[height+1-y;x];
    startRC(1,1:2)=xy2rc(startState(1,1),startState(1,2));
    goalRC(1,1:2)=xy2rc(goalState(1,1),goalState(1,2));
    tempConstraints = constraints;
    maxTime=0;
    if size(tempConstraints,1)~=0
        tempConstraints(:,1)=height+1-constraints(:,2);
        tempConstraints(:,2)=constraints(:,1);
        tempConstraints(:,3)=tempConstraints(:,3)-ctime;
        %find future occupied temporal-spatial locations by higher priority
        %robots
        vec = ismember(tempConstraints(:,1:2),goalRC,'rows');
        indices = find(vec==1);
        sb = tempConstraints(indices',:);
        maxTime = max(sb(:,3));
        if isempty(maxTime)
            maxTime=0;
        end
    end
        
    %AStartSTT start from time=0
    tempPath=AlgAStarST(mapGrid,startRC,goalRC,tempConstraints,maxTime);
    path=tempPath;
    path(:,1)=tempPath(:,2);
    path(:,2)=height+1-tempPath(:,1);
    path(:,3)=path(:,3)+ctime;        
end


