function [successFlag,costVec,computeTime,AllPathCell,priorityVec] = MRPP_PP(robotNum,mapGrid,StartRobotStates,GoalRobotStates,ctime,planTime)
successFlag=1;
computeTime=0;
costVec=zeros(robotNum,1);

AllPathCell=cell(robotNum,1);
currentTSTable=[];
t1=clock;
%priority assignment
len = zeros(robotNum,1);
slack = zeros(robotNum,1);
for i=1:robotNum
    path = singlePlannerForPP(mapGrid,StartRobotStates(i,:),GoalRobotStates(i,:),0,[]);
    len(i,1) = size(path,1);
    slack(i,1) = GoalRobotStates(i,3)-size(path,1);
end
priorityVec = zeros(robotNum,1);
%[~,I]=sort(slack); %slack heuristic
[~,I]=sort(len,'descend'); %longest first heuristic
priorityVec = I;
for i=1:robotNum
    index = find(priorityVec==i);
    tempPath=singlePlannerForPP(mapGrid,StartRobotStates(index,:),GoalRobotStates(index,:),ctime,currentTSTable);
    if size(tempPath,1)==1 || size(tempPath,1)>=planTime
        successFlag=0;
        break;
    end
    pathLength=size(tempPath,1);
    costVec(index,1) = pathLength;
    sb=tempPath(end,:);
    %makesure robots stays forever on the goal station.
    for j=1:planTime-pathLength
        tempPath(pathLength+j,:)=[sb(1,1:3),j+pathLength];
    end
    AllPathCell{index,1}=tempPath;
    tempPath(:,3)=tempPath(:,4);
    tempPath(:,4)=[];
    currentTSTable=[currentTSTable;tempPath];
end
t2=clock;
computeTime=etime(t2,t1);
if successFlag == 0
    computeTime = 0;
    costVec = zeros(robotNum,1);
    AllPathCell = [];
end

end

