function distance = getDistance(location1,location2)
global WarehouseMap;
allStations = WarehouseMap.AllStations;
distanceMat = WarehouseMap.DistanceMat;
[indices1,~]=ismember(allStations,location1,'rows');
[indices2,~]=ismember(allStations,location2,'rows');
distance = distanceMat(indices1==1,indices2==1);

if isempty(distance)
    distance = abs(location1(1,1)-location2(1,1))+abs(location1(1,2)-location2(1,2));
    disp("station not found, return block distance"); 
elseif distance == 0 
    index1 = find(indices1==1);
    index2 = find(indices2==1);
    if index1 == 0 || index2 == 0
        disp("both stations cannot be found");
    elseif index1 == index2
        %disp("the same station");
    else
        disp("distance error");        
    end 
end

end