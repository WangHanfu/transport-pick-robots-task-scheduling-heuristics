clear;
clc;
%rng default

% some effects

n=32; % pick robot number
combinationNum = 50;
InstanceSet = cell(6,combinationNum);

global WarehouseMap
load('WarehouseMap32.mat');
WorkZones = WarehouseMap.WorkZones;

for p=1:6
    m = 5*p;
    taskNum = m; % task number
    for q=1:combinationNum
        TransportRobotSet = cell(m,1);
        PickRobotSet = cell(n,1);
        deliveryStationNum = size(WarehouseMap.DeliveryStations,1);
        randomStart = randperm(deliveryStationNum); % transport robot start from random delivery stations
        
        for i=1:m
            TransportRobotSet{i,1}=ClassTransportRobot;
            type = 0;
            TransportRobotSet{i,1}.setAttribute(i,type,WarehouseMap.DeliveryStations(randomStart(i),:),[] );
        end
        
        for j=1:n
            PickRobotSet{j,1}=ClassPickRobot;
            type = 1;
            PickRobotSet{j,1}.setAttribute(j,type,[],WorkZones(j,:) );
        end
        
        % mission generation
        cycle = size(WarehouseMap.PickupStations,1);
        vec=randperm(cycle);
                                      
        for i=1:taskNum
            TaskSet{i,1}=ClassTask;
            %subtaskNum = randi([4 6]);
            subtaskNum = 10;
            currentPickupStations = zeros(subtaskNum,2);
            pickupZones = zeros(subtaskNum,1);
            if size(vec,2)<=subtaskNum
                vec=[vec randperm(cycle)];
            end
            for j = 1:subtaskNum
                loc = WarehouseMap.RendezvousStations(vec(j),:);
                currentPickupStations(j,:) = loc;
                for k = 1:size(WorkZones,1)
                    zone = WorkZones(k,:);
                    if loc(1,1)>=zone(1,1) && loc(1,1)<=zone(1,2) && loc(1,2)>=zone(1,3) && loc(1,2)<=zone(1,4)
                        pickupZones(j,1) = k;
                        break;
                    end
                end
            end
            vec(1:subtaskNum)=[];
            TaskSet{i,1}.setAttribute(i,subtaskNum,currentPickupStations,pickupZones,TransportRobotSet{i,1}.State);
        end
        
    instance.TransportRobotSet = TransportRobotSet;
    instance.PickRobotSet = PickRobotSet;
    instance.TaskSet = TaskSet;
    InstanceSet{p,q} = instance;
    fprintf("%d,%d,\n",p,q);    
    end
end

save("Instance32.mat","InstanceSet");
