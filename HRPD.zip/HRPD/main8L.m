%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Heterogeneous Multi-robot System
% Author: Wang Hanfu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear;
clc;
%rng default

n=8; % pick robot number

combinationNum = 50;

global WarehouseMap
global TaskSet
global TransportRobotSet
global PickRobotSet
global subtaskDistributionMat
global blockWidthVec
global subtaskIDCell
global subtaskStationCell
global subtaskPTimeMat

global WarehouseMap
load('WarehouseMap8.mat');
WorkZones = WarehouseMap.WorkZones;

load('Instance8L.mat');
Results = cell(6,combinationNum);

%algorithms

for p=6
    for q=16:30
        instance = InstanceSet{p,q};
                
        TaskSet = instance.TaskSet;
        TransportRobotSet = instance.TransportRobotSet;
        PickRobotSet = instance.PickRobotSet;
        m = p*5;
        
        %task allocation
        for i=1:m
            TaskSet{i,1}.PickupSubtaskMat(:,3)=i;
            TaskSet{i,1}.DeliverySubtaskVec(1,3)=i;
        end
        
        [subtaskDistributionMat,blockWidthVec,subtaskIDCell,subtaskStationCell,subtaskPTimeMat] = problem2matrices(TaskSet,m,n);
        Solutions = cell(9,1);
        % choosing algorithms
        for i=1:8              
            tic;            
            switch i
                case 1
                    sequenceMat = TSDecoupled();
                case 2
                    sequenceMat = TSAppend(1);
                case 3
                    sequenceMat = TSAppend(2);
                case 4
                    sequenceMat = TSAppend(3);
                case 5
                    sequenceMat = TSAppend(4);
                case 6
                    sequenceMat = TS3Matching(1);
                case 7
                    sequenceMat = TS2Matching(1);
                case 8
                    sequenceMat = TSInsert(1);
            end
                                    
            computeTime = toc;
            fprintf("%d,%d,algorithm %d\n",p,q,i);
            
            [schedule,TS,PS,TT,PT,TI,PI,TRe,PRe] = computeSchedule(sequenceMat);
            [HA,TA] = computeHeadTail(sequenceMat);
            %sequenceMat
            maxRank = max(max(sequenceMat));
            makespan = max(max(schedule+TRe));
            %plotGantt(sequenceMat,schedule,TS,PS,TT,PT,TI,PI,TRe,PRe,subtaskDistributionMat,blockWidthVec,ColorMat);
            solution.computeTime =  computeTime;
            solution.makespan = makespan;
            solution.sequenceMat = sequenceMat;
            solution.maxRank = maxRank;
            solution.schedule = schedule;
            solution.TS = TS;
            solution.PS = PS;
            solution.TT = TT;
            solution.PT = PT;
            solution.TI = PI;
            solution.TRe = TRe;
            solution.PRe = PRe;
            solution.HA = HA;
            solution.TA = TA;            
            Solutions{i,1}=solution;
        end
        
        %LB
        taskCell = instance.TaskSet;
        vec = zeros(size(taskCell,1),1);
        for i=1:size(taskCell,1)
            task = taskCell{i,1};
            mat = task.PickupSubtaskMat;
            ptimeVec = mat(:,8);
            vec(i,1) = sum(sum(ptimeVec))+task.MinRouteTime;
        end
        Solutions{9,1} = max(vec);
        
        Results{p,q} = Solutions;
    end
end

save("Results8L6_16_30.mat","Results");