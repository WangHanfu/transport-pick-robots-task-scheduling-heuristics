function plotMap(warehouseMap)

rackMarkerSize = 18;
stationMarkerSize = 18;
stationColor = [0.8 0.8 0.8];

rectangle('Position', [0,0,warehouseMap.Width+1,warehouseMap.Height+1],'lineWidth',5);

plot(warehouseMap.PodStates(:,1),warehouseMap.PodStates(:,2),'square','MarkerEdgeColor','k','MarkerFaceColor',[0 0 0],'MarkerSize',rackMarkerSize);
hold on;
plot(warehouseMap.RendezvousStations(:,1),warehouseMap.PickupStations(:,2),'square','MarkerEdgeColor',stationColor,'MarkerFaceColor',stationColor,'MarkerSize',stationMarkerSize);
hold on;
plot(warehouseMap.PickupStations(:,1),warehouseMap.PickupStations(:,2),'square','MarkerEdgeColor',stationColor,'MarkerFaceColor',stationColor,'MarkerSize',stationMarkerSize);
hold on;
plot(warehouseMap.DeliveryStations(:,1),warehouseMap.DeliveryStations(:,2),'square','MarkerEdgeColor',stationColor,'MarkerFaceColor',stationColor,'MarkerSize',stationMarkerSize);

workZones = warehouseMap.WorkZones;
for i=1:size(workZones,1)
    %rectangle('Position', [workZones(i,1)-0.5,workZones(i,3)+0.5,workZones(i,2)-workZones(i,1)+1,workZones(i,4)-workZones(i,3)-1],'lineWidth',1,'lineStyle','-','FaceColor',[0.95 0.95 0.95],'edgeColor','none');
    %rectangle('Position', [workZones(i,1)-0.5,workZones(i,3)+0.5,workZones(i,2)-workZones(i,1)+2,workZones(i,4)-workZones(i,3)-1.2],'lineWidth',1,'lineStyle','-','edgeColor',[0 0 1]);
    rectangle('Position', [workZones(i,1)-0.5,workZones(i,3)-0.5,workZones(i,2)-workZones(i,1)+1,workZones(i,4)-workZones(i,3)+1],'lineWidth',1,'lineStyle','-','edgeColor',[0 0 1]);

end

end

