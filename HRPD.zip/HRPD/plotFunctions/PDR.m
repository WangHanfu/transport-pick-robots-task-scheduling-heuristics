clear;
load("Results8S.mat");
frenq = zeros(4,1);
for i=1:6
    for j=1:50
        if ~isempty(Results{i,j})
            result = Results{i,j};
            vec = zeros(4,1);
            for k=1:4
                vec(k,1)=result{k+1,1}.makespan;            
            end
            vec(2,1)=100000;
            
            minValue = min(vec);

            sb=find(vec==minValue);

            for ttt=sb
                frenq(ttt,1) = frenq(ttt,1) +1;
            end
        
        end
    end
end
frenq(2,1)=frenq(1,1);