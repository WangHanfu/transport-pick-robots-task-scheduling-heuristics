function  plot3DBars(X,Y,ZValue,offset,color)

switch color
    case 1
        sb=[1 0 0];
    case 2
        sb=[0 1 0];
    case 3
        sb=[0 0 1];
    case 4
        sb=[0 0 0];
end

for i=1:length(X)    
    for j=1:length(Y)
        plotcube([0.1 0.1 ZValue(i,j)],[ X(i) Y(j)+offset 0],1,sb);
    end
end

end

