clear;
load("Results32L.mat");

utilityAveMat = zeros(8,6); 
for k=5  
    for i=1:6
        msVec = zeros(1,50);
        tVec = zeros(1,50);  
        for j=1:50
            result = Results{i,j};            
            if ~isempty(result) 
                lb = result{9,1};
                if ~isempty(result{k,1}) 
                    msVec(1,j) = result{k,1}.makespan-lb;
                    tVec(1,j) = result{k,1}.computeTime;
                end
            end                        
        end
        msVec = msVec(msVec~=0);
        utilityAveMat(k,i)=mean(msVec);    
    end
end

utilityAveMat(k,i)=mean(msVec);    
output = utilityAveMat(k,:);
