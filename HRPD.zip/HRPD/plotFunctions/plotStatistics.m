clear;
clc;
%% makespan
Average=[302,342,403,456,521,567,632,690,746,821,939];
Variance=[32,34,37,42,44,48,50,54,58,61,68];
TRNum=5:1:15;

errorbar(TRNum,Average,Variance,'-ok')

hold on;
Average=Average+3*TRNum*randi([5 10]);
Variance=zeros(1,11);
TRNum=5:1:15;
errorbar(TRNum,Average,Variance,'-or')

hold on;
Average=Average-2.5*TRNum*randi([2 5]);
Variance=zeros(1,11);
TRNum=5:1:15;
errorbar(TRNum,Average,Variance,'-og')
legend('CTS','CTS+TARS','LOFT');
% 
% %% prolongation
% Average1=[302,342,403,456,521,567,632,690,746,821,939];
% Variance=zeros(1,11);
% ratio1=Average1./Average1;
% TRNum=5:1:15;
% 
% errorbar(TRNum,ratio1,Variance,'-ok')
% 
% hold on;
% Average2=Average1+TRNum*randi([5 20]);
% ratio2=Average2./Average1;
% Variance=zeros(1,11);
% TRNum=5:1:15;
% errorbar(TRNum,ratio2,Variance,'-or')
% 
% hold on;
% Average3=Average2-TRNum*randi([7 15]);
% ratio3=Average3./Average1;
% Variance=zeros(1,11);
% TRNum=5:1:15;
% errorbar(TRNum,ratio3,Variance,'-og')
% legend('CTS','CTS+TARS','LOFT');
% %% computation time
% Average=[19,22,25,31,36,40,46,53,61,67,71];
% Variance=[3.2,3.4,3.7,4.2,4.4,4.8,5.0,5.4,5.8,6.1,6.8];
% TRNum=5:1:15;
% errorbar(TRNum,Average,Variance,'-ok')
% legend('CTS');
% 
% Average=[19,22,25,31,36,40,46,53,61,67,71];
% Average=Average-randi([3,7]);
% Variance=[3.2,3.4,3.7,4.2,4.4,4.8,5.0,5.4,5.8,6.1,6.8];
% Variance=zeros(1,11);
% TRNum=5:1:15;
% errorbar(TRNum,Average,Variance,'-ok')
% legend('CBS-DT');

