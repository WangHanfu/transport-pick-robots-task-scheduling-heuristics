clear;
load("Results8S6_32_40.mat");
Result1=Results;
%load("Results8L6noInsert.mat");
load("Results8S.mat");
for i=32:40

%for i=44:50
    Results{6,i}=Result1{6,i};
end

save("Results8S.mat","Results");