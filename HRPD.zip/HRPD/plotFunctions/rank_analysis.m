clear;
load("Results8.mat");

logMat=zeros(6,50);

for i=1:6
    for j=1:50
        result = Results{i,j};
        if ~isempty(result)
            sb1 = result{5,1};
            sb2 = result{6,1};
            if  sb1.maxRank==sb2.maxRank
                logMat(i,j)=1;
            end
        end
    end
end

sum(sum(logMat));