clear;
load("Results8S.mat");

makespanAveMat = zeros(8,6); 
makespanStdMat = zeros(8,6); 

timeAveMat = zeros(8,6); 
timeStdMat = zeros(8,6); 

for k=1:8  
    for i=1:6
        msVec = zeros(1,50);
        tVec = zeros(1,50);  
        for j=1:50
            result = Results{i,j};            
            if ~isempty(result) 
                lb = result{9,1};
                if ~isempty(result{k,1}) 
                    msVec(1,j) = result{k,1}.makespan/lb;
                    tVec(1,j) = result{k,1}.computeTime;
                end
            end                        
        end
        msVec = msVec(msVec~=0);
        tVec = tVec(tVec~=0);
        makespanAveMat(k,i)=mean(msVec);    
        makespanStdMat(k,i)=std(msVec);  
        timeAveMat(k,i)=mean(tVec);
        timeStdMat(k,i)=std(tVec);
    end
end

makespanAveMat(k,i)=mean(msVec);    
makespanStdMat(k,i)=std(msVec);  

% makespanAveMat(:,6)=[3.6453
% 2.6543
% 2.4356
% 2.5434
% 2.5434
% 3.1234
% 3.5683
% 2.5321
% ];
% makespanStdMat(:,6)=[0.255009395
% 0.109295919
% 0.106292711
% 0.101923435
% 0.095386218
% 0.110887871
% 0.247593474
% 0.109476861
% ];

sz=get(0,'screensize');
sz(1,2) = 10;
sz(1,4) = 500;
figure(2);
h=figure('outerposition',sz);
assignin('base','h',h); %in case of any callback errors.
%title('Large-scale Heterogeneous Multi-Robot System in Warehouse');
hold on;
grid on;
set(gca,'xtick',50:50:300);
%axis equal;
axis([0 300 1 4]);
%axis manual;
axis square

%% makespan
for i=[1  6 7 2 8]
% for i=[2 3 4 5 6]
%for i=[1 2 3 4 5 6]

    Average = makespanAveMat(i,:);
    Variance = makespanStdMat(i,:);
    TRNum=50:50:300;
    hold on;
    e = errorbar(TRNum,Average,Variance);
    
    if i==1 %decoupled
        e.Marker = 'o';
        e.MarkerSize = 1;
        e.Color = 'black';
        e.CapSize = 15;
    elseif i==2 %AP(1)
        e.Marker = 'o';
        e.MarkerSize = 1;
        e.Color = 'red';
        e.CapSize = 15;
    elseif i==3 %AP(1)
        e.Marker = 'o';
        e.MarkerSize = 1;
        e.Color = 'red';
        e.CapSize = 15;
    elseif i==4 %AP(1)
        e.Marker = 'o';
        e.MarkerSize = 1;
        e.Color = 'red';
        e.CapSize = 15;
    elseif i==5 %AP(1)
        e.Marker = 'o';
        e.MarkerSize = 1;
        e.Color = 'red';
        e.CapSize = 15;
    elseif i==6 %M3
        e.Marker = 'o';
        e.MarkerSize = 1;
        e.Color = 'blue';
        e.CapSize = 15;
    elseif i==7 %M2
        e.Marker = 'o';
        e.MarkerSize = 1;
        e.Color = 'cyan';
        e.CapSize = 15;
    elseif i==8 %IN
        e.Marker = 'o';
        e.MarkerSize = 1;
        e.Color = 'green';
        e.CapSize = 15;
    end
          
end

%xlabel('subtask numbers');
%ylabel('normalized performance ratio');
legend('DC','MT(3)','MT(2)','AP(STD)','IN','Location','NorthWest');
%legend('AP(STD)','AP(LTD)','AP(SOT)','AP(LOT)','IN','Location','NorthWest');

figure(2);
%% makespan
for i=[1  6 7 5 8]
% for i=[2 3 4 5 6]
%for i=[1 2 3 4 5 6]

    Average = timeAveMat(i,:);
    Variance = timeStdMat(i,:);
    TRNum=50:50:300;
    hold on;
    e = errorbar(TRNum,Average,Variance);
    
    if i==1 %decoupled
        e.Marker = 'o';
        e.MarkerSize = 1;
        e.Color = 'black';
        e.CapSize = 15;
    elseif i==2 %AP(1)
        e.Marker = 'o';
        e.MarkerSize = 1;
        e.Color = 'red';
        e.CapSize = 15;
    elseif i==3 %AP(1)
        e.Marker = 'o';
        e.MarkerSize = 1;
        e.Color = 'red';
        e.CapSize = 15;
    elseif i==4 %AP(1)
        e.Marker = 'o';
        e.MarkerSize = 1;
        e.Color = 'red';
        e.CapSize = 15;
    elseif i==5 %AP(1)
        e.Marker = 'o';
        e.MarkerSize = 1;
        e.Color = 'red';
        e.CapSize = 15;
    elseif i==6 %M3
        e.Marker = 'o';
        e.MarkerSize = 1;
        e.Color = 'blue';
        e.CapSize = 15;
    elseif i==7 %M2
        e.Marker = 'o';
        e.MarkerSize = 1;
        e.Color = 'cyan';
        e.CapSize = 15;
    elseif i==8 %IN
        e.Marker = 'o';
        e.MarkerSize = 1;
        e.Color = 'green';
        e.CapSize = 15;
    end
          
end

xlabel('subtask numbers');
ylabel('normalized performance ratio');
legend('DC','MT(3)','MT(2)','AP(LPT)','IN','Location','NorthWest');
%legend('AP(STD)','AP(LTD)','AP(SOT)','AP(LOT)','IN','Location','NorthWest');