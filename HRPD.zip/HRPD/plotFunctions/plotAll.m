function plotAll(warehouseMap,taskSet,m,RobotStates,ColorMat)

% rackMarkerSize = 34;
% stationMarkerSize = 30;
% robotMarkerSize = 20;
% robotRadius = 1;
% fontSize = 16;
rackMarkerSize = 15;
stationMarkerSize = 15;
robotMarkerSize = 10;
robotRadius = 1;
fontSize = 8;
stationColor = [0.8 0.8 0.8];

robotNum=size(RobotStates,1);
rectangle('Position', [0,0,warehouseMap.Width+1,warehouseMap.Height+1],'lineWidth',5);

plot(warehouseMap.PodStates(:,1),warehouseMap.PodStates(:,2),'square','MarkerEdgeColor','k','MarkerFaceColor',[0 0 0],'MarkerSize',rackMarkerSize);
plot(warehouseMap.RendezvousStations(:,1),warehouseMap.PickupStations(:,2),'square','MarkerEdgeColor',stationColor,'MarkerFaceColor',stationColor,'MarkerSize',stationMarkerSize);
plot(warehouseMap.PickupStations(:,1),warehouseMap.PickupStations(:,2),'square','MarkerEdgeColor',stationColor,'MarkerFaceColor',stationColor,'MarkerSize',stationMarkerSize);
plot(warehouseMap.DeliveryStations(:,1),warehouseMap.DeliveryStations(:,2),'square','MarkerEdgeColor',stationColor,'MarkerFaceColor',stationColor,'MarkerSize',stationMarkerSize);

% workZones = warehouseMap.WorkZones;
% for i=1:size(workZones,1)
%     %rectangle('Position', [workZones(i,1)-0.5,workZones(i,3)+0.5,workZones(i,2)-workZones(i,1)+1,workZones(i,4)-workZones(i,3)-1],'lineWidth',1,'lineStyle','-','FaceColor',[0.95 0.95 0.95],'edgeColor','none');
%     rectangle('Position', [workZones(i,1)-1,workZones(i,3)+0.6,workZones(i,2)-workZones(i,1)+2,workZones(i,4)-workZones(i,3)-1.2],'lineWidth',1,'lineStyle','-','edgeColor',[0 0 1]);
% end

for i=1:size(taskSet,1)
    task = taskSet{i,1};
    GoalStates = task.PickupSubtaskMat(:,6:7);
    pickupStates = task.PickupSubtaskMat(:,9);  
    GoalStates(all(pickupStates == 1,2),:) = [];
    plot(task.DeliverySubtaskVec(1,6),task.DeliverySubtaskVec(1,7),'o','MarkerEdgeColor',ColorMat(i,:),'MarkerSize',robotMarkerSize);    
    if ~isempty(GoalStates)
        plot(GoalStates(:,1),GoalStates(:,2),'x','MarkerEdgeColor',ColorMat(i,:),'MarkerFaceColor',ColorMat(i,:),'MarkerSize',robotMarkerSize-2,'LineWidth',2);    
        if size(GoalStates,1) == task.PickupSubtaskNum
            mat = [task.DeliverySubtaskVec(1,6:7);GoalStates;task.DeliverySubtaskVec(1,6:7)];            
        else
            mat = [GoalStates;task.DeliverySubtaskVec(1,6:7)];
        end
        %line([mat(1:end-1,1)',mat(2:end,1)'],[mat(1:end-1,2)',mat(2:end,2)'],'Color',ColorMat(i,:));
    end    
end

for i=1:m
    plot(RobotStates(i,1),RobotStates(i,2),'o','MarkerEdgeColor','k','MarkerFaceColor',ColorMat(i,:),'MarkerSize',robotMarkerSize);    
    txt=sprintf('%d',i);
    text(RobotStates(i,1),RobotStates(i,2),txt,'FontWeight','Bold','FontSize',fontSize,'HorizontalAlignment','center','Color',[1 1 1]);
end

for i=m+1:robotNum
    plot(RobotStates(i,1),RobotStates(i,2),'o','MarkerEdgeColor','k','MarkerFaceColor',[1 1 1],'LineWidth',1,'MarkerSize',robotMarkerSize);
    txt=sprintf('%d',i-m);
    text(RobotStates(i,1),RobotStates(i,2),txt,'FontWeight','Bold','FontSize',fontSize,'HorizontalAlignment','center','Color',[0 0 0]);
end



end

