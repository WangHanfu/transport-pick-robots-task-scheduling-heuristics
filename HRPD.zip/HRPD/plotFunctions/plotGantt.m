function  plotGantt(sequenceMat,schedule,TS,PS,TT,PT,TI,PI,TRe,PRe,subtaskDistributionMat,blockWidthVec,ColorMat)

[m,n] = size(subtaskDistributionMat);
grid on;
travelColor = [0.8 0.8 0.8];

makespan = max(max(schedule+TRe));

barWidth = 0.6;
XLength = makespan;
YLength = n+m+1;
axis([0,XLength,0,YLength+1]);
%set(gca,'xtick',0:50:XLength);
set(gca,'ytick',0:1:YLength);
set(gca,'YTick', []);
%xlabel('Time/s','FontName','΢���ź�','Color','k','FontSize',16);
%ylabel('Robot/ID','FontName','΢���ź�','Color','k','FontSize',16,'Rotation',90);
%title('Optimal Task Scheduling for Robots','fontname','΢���ź�','Color','k','FontSize',16);

% separate two types of robots
line([0,XLength],[m+1,m+1],'color','k','LineWidth',1);
%pause(1);

maxRank = max(max(sequenceMat));
for rank = 1:maxRank
    [rows,cols]=find(sequenceMat==rank);
    if ~isempty(rows)
        for j=1:size(rows,1)
            r = rows(j,1);
            c = cols(j,1);
            
            transportID = r;
            [pickID,~] = col2jk(c,blockWidthVec);
            
            
            %% Transport robots
            %[x y w h]
            rec=zeros(1,4);
            rec(1,1) = TS(r,c);
            rec(1,2) = transportID;
            rec(1,3) = TT(r,c);
            rec(1,4) = barWidth;
            rectangle('Position',rec,'LineWidth',1,'LineStyle','-','FaceColor',travelColor);
            %TRPT
            rec=zeros(1,4);
            rec(1,1) = TS(r,c)+TT(r,c)+TI(r,c);
            rec(1,2) = transportID;
            rec(1,3) = schedule(r,c)-rec(1,1);
            rec(1,4) = barWidth;
            rectangle('Position',rec,'LineWidth',1,'LineStyle','-','FaceColor',ColorMat(transportID,:));
            
            % the last subtask of a transport robot
            if rank == max(sequenceMat(transportID,:))
                rec=zeros(1,4);
                rec(1,1) = schedule(r,c);
                rec(1,2) = transportID;
                rec(1,3) = TRe(r,c);
                rec(1,4) = barWidth;
                rectangle('Position',rec,'LineWidth',1,'LineStyle','-','FaceColor',travelColor);
            end
            
            %% pick robots
            %Pick robot, travel duration
            %[x y w h]
            rec=zeros(1,4);
            rec(1,1) = PS(r,c);
            rec(1,2) = m + pickID;
            rec(1,3) = PT(r,c);
            rec(1,4) = barWidth;
            rectangle('Position',rec,'LineWidth',1,'LineStyle','-','FaceColor',travelColor);
            %TRPT
            rec=zeros(1,4);
            rec(1,1) = PS(r,c)+PT(r,c)+PI(r,c);
            rec(1,2) = m+pickID;
            rec(1,3) = schedule(r,c)-rec(1,1);
            rec(1,4) = barWidth;
            rectangle('Position',rec,'LineWidth',1,'LineStyle','-','FaceColor',ColorMat(transportID,:));
            
        end
    end
    %pause(1);
end

end

