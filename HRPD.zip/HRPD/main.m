%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Heterogeneous Multi-robot System
% Author: Wang Hanfu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear;
clc;
%rng default

% some effects
enableMapGeneration = 0;
enableVideoRecord = 0;
enableTaskGeneration = 0;
selectTaskSchedulingAlgorithm = 4;

m=30; % transport robot number
n=32; % pick robot number
taskNum = m; % task number

%map parameters.
width=52;
height=39;
rackLength = 10;
rackNumVec = [9 4];
aisleWidth = 3;
crossAisleWidth = 2;
topLeftRC = [4 4];

% simulation and plot parameters
frameRate = 5;
ColorMat = rand(m,3);

global WarehouseMap
global TaskSet
global TransportRobotSet
global PickRobotSet
global subtaskDistributionMat
global blockWidthVec
global subtaskIDCell
global subtaskStationCell
global subtaskPTimeMat

%% map class
%manual generation of pick robots workzones
% in warehouse class, the computation of distanceMatrix is very time-consuming.
% so we choose saved warehouse map

if enableMapGeneration
    WorkZones=zeros(n,4);
    WorkZones(1,:)=[4 13 5 7];
    WorkZones(2,:)=[16 25 5 7];
    WorkZones(3,:)=[28 37 5 7];
    WorkZones(4,:)=[40 49 5 7];
    for i=1:7
        WorkZones(1+i*4,:)=[4 13 5+i*4 7+i*4];
        WorkZones(2+i*4,:)=[16 25 5+i*4 7+i*4];
        WorkZones(3+i*4,:)=[28 37 5+i*4 7+i*4];
        WorkZones(4+i*4,:)=[40 49 5+i*4 7+i*4];
    end
    
    WarehouseMap = ClassMap(width,height,rackLength,rackNumVec,aisleWidth,crossAisleWidth,topLeftRC,WorkZones);    
    plotMap(WarehouseMap);
    save('WarehouseMapLarge.mat','WarehouseMap');
else    
    load('WarehouseMap32.mat');
    %plotMap(WarehouseMap);
    WorkZones = WarehouseMap.WorkZones;
end

%% classes: RobotSet; TaskSet

TransportRobotSet = cell(m,1);
PickRobotSet = cell(n,1);
deliveryStationNum = size(WarehouseMap.DeliveryStations,1);
randomStart = randperm(deliveryStationNum); % transport robot start from random delivery stations

for i=1:m
    TransportRobotSet{i,1}=ClassTransportRobot;
    type = 0;
    TransportRobotSet{i,1}.setAttribute(i,type,WarehouseMap.DeliveryStations(randomStart(i),:),[] );
end

for j=1:n
    PickRobotSet{j,1}=ClassPickRobot;
    type = 1;
    PickRobotSet{j,1}.setAttribute(j,type,[],WorkZones(j,:) );
end

% mission generation
if enableTaskGeneration == 1
    cycle = size(WarehouseMap.PickupStations,1);
    vec=randperm(cycle);
    TaskSet = cell(taskNum,1);
    for i=1:taskNum
        TaskSet{i,1}=ClassTask;
        %subtaskNum = randi([4 6]);
        subtaskNum = 10;
        currentPickupStations = zeros(subtaskNum,2);
        pickupZones = zeros(subtaskNum,1);
        if size(vec,2)<=subtaskNum
            vec=[vec randperm(cycle)];
        end
        for j = 1:subtaskNum
            loc = WarehouseMap.RendezvousStations(vec(j),:);
            currentPickupStations(j,:) = loc;
            for k = 1:size(WorkZones,1)
                zone = WorkZones(k,:);
                if loc(1,1)>=zone(1,1) && loc(1,1)<=zone(1,2) && loc(1,2)>=zone(1,3) && loc(1,2)<=zone(1,4)
                    pickupZones(j,1) = k;
                    break;
                end
            end
        end
        vec(1:subtaskNum)=[];
        TaskSet{i,1}.setAttribute(i,subtaskNum,currentPickupStations,pickupZones,TransportRobotSet{i,1}.State);
    end
    save('instance.mat','TaskSet','TransportRobotSet','PickRobotSet');
end

load('Instance32S.mat');

TaskSet = InstanceSet{6,1}.TaskSet;
TransportRobotSet = InstanceSet{6,1}.TransportRobotSet;
PickRobotSet = InstanceSet{6, 1}.PickRobotSet;

%% One-shot Task Allocation
for i=1:taskNum
    TaskSet{i,1}.PickupSubtaskMat(:,3)=i;
    TaskSet{i,1}.DeliverySubtaskVec(1,3)=i;
end

%% Task Scheduling
[subtaskDistributionMat,blockWidthVec,subtaskIDCell,subtaskStationCell,subtaskPTimeMat] = problem2matrices(TaskSet,m,n);

tic;
switch selectTaskSchedulingAlgorithm
    case 1
        sequenceMat = TSDecoupled();
    case 2
        sequenceMat = TS3Matching(1);
    case 3
        sequenceMat = TSAppend(4);
    case 4
        sequenceMat = TSInsert(1);
end

toc;

[schedule,TS,PS,TT,PT,TI,PI,TRe,PRe] = computeSchedule(sequenceMat);
[HA,TA] = computeHeadTail(sequenceMat);

sequenceMat
schedule+TRe
TRe
makespan = max(max(schedule+TRe))

HA+TA+subtaskPTimeMat

plotGantt(sequenceMat,schedule,TS,PS,TT,PT,TI,PI,TRe,PRe,subtaskDistributionMat,blockWidthVec,ColorMat);

%% simulation initialization
if enableVideoRecord == 1
    video = VideoWriter('simulation');
    video.FrameRate=frameRate;
    open(video);
end

sz=get(0,'screensize');
sz(1,2) = 10;
sz(1,4) = 1080;
figure(2);
h=figure('outerposition',sz);
assignin('base','h',h); %in case of any callback errors.
%title('Large-scale Heterogeneous Multi-Robot System in Warehouse');
hold on;
grid on;
set(gca,'xtick',0:1:WarehouseMap.Width);
set(gca,'ytick',0:1:WarehouseMap.Height);
axis equal;
axis([0 WarehouseMap.Width+1 0 WarehouseMap.Height+1]);
axis manual;

%% Simulation Running Process

FormerRobotStates = zeros(m+n,2);
for i=1:m+n
    if i<=m
        FormerRobotStates(i,:) = TransportRobotSet{i,1}.State;
    else
        FormerRobotStates(i,:) = PickRobotSet{i-m,1}.State;
    end
end
CurrentRobotStates = FormerRobotStates;%only used to plot

PathCell = cell(m+n,1);
for i=1:m+n
    PathCell{i}=[];
end

pickupExecutionMat = subtaskPTimeMat~=0 ;
pickupExecutionMat = double(pickupExecutionMat);

deliveryExecutionMat = ones(taskNum,1);

[transportOrderMat,pickOrderMat]= sequence2order(sequenceMat,subtaskDistributionMat,blockWidthVec);

realSchedule = zeros(m,sum(blockWidthVec));
realPS = zeros(m,sum(blockWidthVec));
realTS = zeros(m,sum(blockWidthVec));
realPT = zeros(m,sum(blockWidthVec));
realTT = zeros(m,sum(blockWidthVec));
realPI = zeros(m,sum(blockWidthVec));
realTI = zeros(m,sum(blockWidthVec));

realPRe = zeros(m,sum(blockWidthVec));
realTRe = zeros(m,sum(blockWidthVec));

realPTCount = subtaskPTimeMat;

%% main loop
simTime = 0;

while( any(any(pickupExecutionMat)) )
    %while( any(deliveryExecutionMat) )
    
    %% task planning
    for i = 1:m
        if TransportRobotSet{i,1}.Status == 0
            maskMat = transportOrderMat;
            maskMat(1:i-1,:) = 0;
            maskMat(i+1:end,:) = 0;
            
            mat2 = maskMat(maskMat~=0);
            minOrder = min(min(mat2));
            
            if ~isempty(minOrder) %have unfinished subtasks
                [r,c] = find(maskMat == minOrder);
                subtaskID = subtaskIDCell{r,c};
                TransportRobotSet{i,1}.BlockID = [r c];
                TransportRobotSet{i,1}.Status = 1;
                path = AlgSinglePlanner(WarehouseMap.MapGrid,TransportRobotSet{i,1}.State,subtaskStationCell{r,c},simTime,[]);
                PathCell{i,1} = path;
                
                TaskSet{subtaskID(1,1),1}.PickupSubtaskMat(subtaskID(1,2),3) = i; % TRID
                
                realTS(r,c) = simTime;
                transportOrderMat(r,c) = 0;
                
                fprintf("Time %d:Transport robot %d starts subtask (%d %d)\n",simTime,i,subtaskID(1,1),subtaskID(1,2));
            end
        end
    end
    
    for j = 1:n
        if PickRobotSet{j,1}.Status == 0
            totalNum = sum(blockWidthVec(1,1:j));
            maskMat = pickOrderMat;
            if j == 1
                maskMat(:,totalNum+1:end) = 0;
            else
                maskMat(:,1:totalNum-blockWidthVec(1,j)) = 0;
                maskMat(:,totalNum+1:end) = 0;
            end
            
            mat2 = maskMat(maskMat~=0);
            minOrder = min(min(mat2));
            
            if ~isempty(minOrder) %have unfinished subtasks
                [r,c] = find(maskMat == minOrder);
                subtaskID = subtaskIDCell{r,c};
                PickRobotSet{j,1}.BlockID = [r,c];
                PickRobotSet{j,1}.Status = 1;
                path = AlgSinglePlanner(WarehouseMap.MapGrid,PickRobotSet{j,1}.State,subtaskStationCell{r,c},simTime,[]);
                PathCell{m+j,1} = path;
                
                TaskSet{subtaskID(1,1),1}.PickupSubtaskMat(subtaskID(1,2),4) = j; % PRID
                
                realPS(r,c) = simTime;
                pickOrderMat(r,c) = 0;
                fprintf("Time %d: Pick robot %d starts subtask (%d %d)\n",simTime,j,subtaskID(1,1),subtaskID(1,2));
            end
        end
    end
    
    %% update robot locations and states
    for i = 1:m+n
        path = PathCell{i,1};
        if ~isempty(path)
            if i<=m
                TransportRobotSet{i,1}.State = path(1,1:2);
                CurrentRobotStates(i,:) = TransportRobotSet{i,1}.State;
            else
                PickRobotSet{i-m,1}.State = path(1,1:2);
                CurrentRobotStates(i,:) = PickRobotSet{i-m,1}.State;
            end
            path(1,:) = [];
            PathCell{i,1} = path;
            if isempty(path) % arrived
                if i<= m
                    id = TransportRobotSet{i,1}.BlockID;
                    realTT(id(1,1),id(1,2)) = simTime - realTS(id(1,1),id(1,2)) ;
                else
                    id = PickRobotSet{i-m,1}.BlockID;
                    realPT(id(1,1),id(1,2)) = simTime - realPS(id(1,1),id(1,2));
                end
            end
        end
        
    end
    
    % update task information
    for i=1:m
        for j = 1:sum(blockWidthVec)
            if subtaskPTimeMat(i,j) ~= 0
                if pickupExecutionMat(i,j) == 1
                    if realTT(i,j)~=0 && realPT(i,j)~=0
                        %                         time3 = max(realPS(i,j)+realPT(i,j),realTS(i,j)+realTT(i,j));
                        %                         realPI(i,j) = time3 - realPS(i,j) - realPT(i,j);
                        %                         realTI(i,j) = time3 - realTS(i,j) - realTT(i,j);
                        realTI(i,j) = simTime - realTS(i,j) - realTT(i,j);
                        realPI(i,j) = simTime - realPS(i,j) - realPT(i,j);
                        pickupExecutionMat(i,j) = 2;
                        %disp([i j]);
                    end
                elseif   pickupExecutionMat(i,j) == 2
                    if realPTCount(i,j) == 1 %%%%next timestep
                        pickupExecutionMat(i,j) = 0;
                        realSchedule(i,j) = simTime + 1; %%%%next timestep
                        subtaskID = subtaskIDCell{i,j};
                        vec = TaskSet{subtaskID(1,1),1}.PickupSubtaskMat(subtaskID(1,2),3:4);
                        TransportRobotSet{vec(1,1),1}.Status = 0;
                        PickRobotSet{vec(1,2),1}.Status = 0;
                        fprintf("Subtask (%d %d) is finished by transport robot %d and pick robot %d\n",subtaskID(1,1),subtaskID(1,2),vec(1,1),vec(1,2));
                    else
                        realPTCount(i,j) = realPTCount(i,j)-1;
                    end
                end
                
            end
        end
        
    end
    
    %% update delivery task
    
    %% display and video generation
    for i=0:frameRate-1
        tempRobotStates = FormerRobotStates+i*(CurrentRobotStates-FormerRobotStates)/frameRate;
        plotAll(WarehouseMap,TaskSet,m,tempRobotStates,ColorMat);
        if enableVideoRecord == 1
            frame = getframe;
            writeVideo(video,frame);
        else
            %pause(0.2/frameRate);
            pause(0.0001);
        end
        cla;
    end
    FormerRobotStates = CurrentRobotStates;
    simTime = simTime+1;
end

isequal(realTT,TT)
isequal(realPT,PT)
isequal(realTI,TI)
isequal(realPI,PI)
isequal(realSchedule,schedule)

figure(5);
plotGantt(sequenceMat,realSchedule,realTS,realPS,realTT,realPT,realTI,realPI,TRe,PRe,subtaskDistributionMat,blockWidthVec,ColorMat);

if enableVideoRecord == 1
    close(video);
end
