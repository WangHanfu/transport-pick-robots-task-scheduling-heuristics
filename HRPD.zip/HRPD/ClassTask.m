classdef ClassTask<handle
    
    properties
        TaskID    
        State %0=unallocated, 1=allocated, 2=finished. ��ʼ��0�������������1��TR��2.  
        PickupSubtaskNum
        PickupSubtaskMat
        DeliverySubtaskVec                
        MinRouteTime           
    end
    
    methods
        function obj = ClassTask()
        end
        
        function setAttribute(obj,taskID,pickupSubtaskNum,pickupStations,PRIDs,deliveryStation,bbb)
            obj.TaskID = taskID;   
            obj.State = 0;
            obj.PickupSubtaskNum = pickupSubtaskNum;
            
            %[route,obj.MinRouteTime] = TSPOptimization(pickupStations,deliveryStation);
            route = 1:10;
            route = route';
            obj.MinRouteTime = bbb;
                        
           %% pickup tasks
            %8 colomns. (taskID,subtaskID,TRID,PRID,k-th ID,x,y,ptime)
            pickupSubtasks = zeros(pickupSubtaskNum,9);
            multipleTimes = zeros(max(PRIDs),1);
            for i=1:pickupSubtaskNum
                pickupSubtasks(i,1) = taskID; %taskID
                pickupSubtasks(i,2) = i; %subtaskID
                
                pickupSubtasks(i,3) = 0; % yet to be allocated to a TR
                zoneID = PRIDs(route(i),1);
                pickupSubtasks(i,4) =  zoneID; %PRID or zone ID
                multipleTimes(zoneID,1) = multipleTimes(zoneID,1)+1;
                pickupSubtasks(i,5) = multipleTimes(zoneID,1); %k-th subtask in the same zone
                
                pickupSubtasks(i,6:7) = pickupStations(route(i),:); %[x y]                
                pickupSubtasks(i,8) = randi([10 20]);  % ptime,uniform distribution
            end
            obj.PickupSubtaskMat = pickupSubtasks;
            
           %% delivery task
            deliverySubtask = zeros(1,8);
            deliverySubtask(1,1) = taskID; %taskID
            deliverySubtask(1,2) = 0; %subtaskID
            deliverySubtask(1,3:5) = [0 0 0]; %
            deliverySubtask(1,6:7) = deliveryStation; %[x y]
            deliverySubtask(1,8) = randi([10 20]);  % uniform distribution
            
            obj.DeliverySubtaskVec = deliverySubtask;                      
        end        
    end %methods
end