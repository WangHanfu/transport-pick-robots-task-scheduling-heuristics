clear;
clc;
load("Instance8S.mat");

for p=1:6
    for q=1:50
        tasks = InstanceSet{p,q}.TaskSet;
        for i=1:size(tasks,1)
            task = tasks{i,1};
            mat = task.PickupSubtaskMat;
            mat(:,8) = (mat(:,8) -10)*4+10;
            vec = task.DeliverySubtaskVec;
            vec(1,8) = (vec(1,8) -10)*4+10;
            task.DeliverySubtaskVec = vec;            
            task.PickupSubtaskMat = mat;
        end
    end
end

save("Instance8L.mat","InstanceSet");