classdef ClassMap<handle
    
    properties
        Width
        Height
        
        MapGrid
        
        PodStates
        
        PickupStations
        RendezvousStations
        DeliveryStations   
        AllStations
        
        WorkZones
        
        DistanceMat
    end
    
    methods
        function obj = ClassMap(width,height,rackLength,rackNumVec,aisleWidth,crossAisleWidth,topLeftRC,workZones)
            obj.Width = width;
            obj.Height = height;
            obj.WorkZones = workZones;
            
            rc2xy=@(r,c)[c;height+1-r];
            
            mapGrid = zeros(height,width);
            RendezvousStationGrid = zeros(height,width);
            
            %% racks grid
            %row indices
            rows = zeros(1,rackNumVec(1,1));
            for i=1:rackNumVec(1,1)
                rows(1,i) = topLeftRC(1,1)+(i-1)*(1+aisleWidth);
            end
            
            %col indices
            cols=zeros(1,rackNumVec(1,2)*rackLength);
            pickupCols=zeros(1,rackNumVec(1,2)*rackLength/2);
            index = 1;
            index2 = 1;
            for i=1:rackNumVec(1,2)
                cols(1,index:index+rackLength-1) = topLeftRC(1,2)+(i-1)*(rackLength+crossAisleWidth):topLeftRC(1,2)+(i-1)*(rackLength+crossAisleWidth)+rackLength-1;
                pickupCols(1,index2:index2+rackLength/2-1) = topLeftRC(1,2)+(i-1)*(rackLength+crossAisleWidth):2:topLeftRC(1,2)+(i-1)*(rackLength+crossAisleWidth)+rackLength-1;
                index = index+rackLength;
                index2 = index2+rackLength/2;
            end
            
            %% generate racks, stations
            for i=rows
                mapGrid(i,cols)=1;
                if i~=min(rows)
                    RendezvousStationGrid(i-1,pickupCols)=1;
                end
                if i~=max(rows)
                    RendezvousStationGrid(i+1,pickupCols)=1;
                end
            end
            
            %pod states
            [R,C]=find(mapGrid==1);
            podNum=size(R,1);
            PodStates = zeros(podNum,2);
            for i=1:podNum
                PodStates(i,:)=rc2xy(R(i,1),C(i,1));
            end
            
            %pickup station states
            [R,C]=find(RendezvousStationGrid==1);
            RendezvousStations=zeros(size(R,1),2);
            for i=1:size(R,1)
                RendezvousStations(i,:)=rc2xy(R(i,1),C(i,1));
            end
            
            %delivery station states
            sb=1;
            deliveryRows=topLeftRC(1,1):max(rows);
            %deliveryCols=[1 4 width width-3];
            deliveryCols=[1 width];
            DeliveryStations=[];
            for i=deliveryCols
                temp=zeros(size(deliveryRows,2),2);
                temp(:,1)=deliveryRows';
                temp(:,2)=i*ones(size(deliveryRows,2),1);
                DeliveryStations=[DeliveryStations;temp];
            end
            
            sb=1;
            deliveryCols2=topLeftRC(1,2):max(cols);
            deliveryRows2=[1 height];
            for i=deliveryRows2
                temp=zeros(size(deliveryCols2,2),2);
                temp(:,2)=deliveryCols2';
                temp(:,1)=i*ones(size(deliveryCols2,2),1);
                DeliveryStations=[DeliveryStations;temp];
            end
                                   
            deliveryStationNum=size(DeliveryStations,1);
            for i=1:deliveryStationNum
                DeliveryStations(i,:)=rc2xy(DeliveryStations(i,1),DeliveryStations(i,2));
            end
                                               
            obj.MapGrid = mapGrid;
            obj.PodStates = PodStates;
            obj.PickupStations = RendezvousStations;
            obj.PickupStations(:,1) = RendezvousStations(:,1)+1;
            obj.RendezvousStations = RendezvousStations;
            obj.DeliveryStations = DeliveryStations;
            
            AllStations = [obj.PickupStations;obj.RendezvousStations;obj.DeliveryStations];
            stationNum = size(AllStations,1);
            obj.AllStations = AllStations;
            distanceMat = zeros(stationNum);
            for i=1:stationNum
                for j=1:stationNum
                    
                    if i==j
                        continue;
                    elseif i<j
                        path = AlgSinglePlanner(obj.MapGrid,AllStations(i,:),AllStations(j,:),0,[]);                       
                        distanceMat(i,j)=size(path,1)-1;
                        disp(AllStations(i,:));
                        disp(AllStations(j,:));
                        fprintf("***********%d,%d,%d\n",i,j,distanceMat(i,j));
                    else
                        distanceMat(i,j)=distanceMat(j,i);
                    end                    
                end
            end
            obj.DistanceMat = distanceMat;
        end
    end %methods
end