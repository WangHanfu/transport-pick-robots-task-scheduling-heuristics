%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Heterogeneous Multi-robot System
% Author: Wang Hanfu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear;
clc;
%rng default

load('warehouseMap.mat');
global WarehouseMap
global RobotSet
global MissionSet
global PickupTaskArray
global pickupTaskNumMat
global pickupTaskBlockWidthVec
global ColorMat
global currentTSTable

% some effects
enableVideo = 0;
enableMission = 0;

TRNum=8;
PRNum=8;
robotNum = TRNum+PRNum;
missionNum = TRNum;

%map parameters.
width=54;
height=41;
rackLength = 10;
rackNumVec = [9 4];
aisleWidth = 3;
crossAisleWidth = 2;
topLeftRC = [5 5];

% simulation parameters
simTime = 0;
frameRate = 5;
ColorMat = rand(robotNum,3);

%% classes: RobotSet; MissionSet
%manual generation of pick robots workzones
WorkZones=zeros(PRNum,4);
WorkZones(1,:)=[5 26 5 13];
WorkZones(2,:)=[5 26 13 21];
WorkZones(3,:)=[5 26 21 29];
WorkZones(4,:)=[5 26 29 37];
WorkZones(5,:)=[29 50 5 13];
WorkZones(6,:)=[29 50 13 21];
WorkZones(7,:)=[29 50 21 29];
WorkZones(8,:)=[29 50 29 37];

% in warehouse class, the computation of distanceMatrix is very time-consuming.
%WarehouseMap = ClassMap(width,height,rackLength,rackNumVec,aisleWidth,crossAisleWidth,topLeftRC,WorkZones);

RobotSet = cell(robotNum,1);
deliveryStationNum = size(WarehouseMap.DeliveryStations,1);
randomStart = randperm(deliveryStationNum); % transport robot start from random delivery stations

for i=1:robotNum
    RobotSet{i,1}=ClassRobot;
    if i<=TRNum
        type = 0;
        RobotSet{i,1}.setAttribute(i,type,WarehouseMap.DeliveryStations(randomStart(i),:),[]);
    else
        type = 1;
        RobotSet{i,1}.setAttribute(i,type,[],WorkZones(i-TRNum,:));
    end
end

%centralized mission generation
if enableMission == 1
    cycle = size(WarehouseMap.PickupStations,1);
    vec=randperm(cycle);
    MissionSet = cell(missionNum,1);
    for i=1:missionNum
        MissionSet{i,1}=ClassMission;
        num = randi([4 6]);
        currentPickupStations = zeros(num,2);
        pickupZones = zeros(num,1);
        if size(vec,2)<=num
            vec=[vec randperm(cycle)];
        end
        for j = 1:num
            loc = WarehouseMap.RendezvousStations(vec(j),:);
            currentPickupStations(j,:) = loc;
            for k = 1:size(WorkZones,1)
                zone = WorkZones(k,:);
                if loc(1,1)>=zone(1,1) && loc(1,1)<=zone(1,2) && loc(1,2)>=zone(1,3) && loc(1,2)<=zone(1,4)
                    pickupZones(j,1) = k;
                    break;
                end
            end
        end
        vec(1:num)=[];
        MissionSet{i,1}.setAttribute(i,num,currentPickupStations,pickupZones,RobotSet{i,1}.InitialState);
    end
    save('instance.mat','MissionSet','RobotSet');
end

load('instance.mat');

CurrentRobotStates = zeros(robotNum,2);
for i=1:robotNum
    CurrentRobotStates(i,:) = RobotSet{i,1}.State;
end
NextRobotStates = CurrentRobotStates;%only used to plot

MessagePassing = cell(robotNum,1);
for i=1:robotNum
    MessagePassing{i,1}.Type = 0;
    if i>TRNum
        MessagePassing{i,1}.Type = 1;
    end
    MessagePassing{i,1}.MissionID = 0;
    MessagePassing{i,1}.TaskID = 0;
    MessagePassing{i,1}.Property = 0;
    MessagePassing{i,1}.Value = 0;
end
PathCell = cell(robotNum,1);
for i=1:robotNum
    sb = repmat(RobotSet{i,1}.State,100,1);
    sb(1:100,3)=(1:100)';
    PathCell{i}=sb;
end

%% Task Scheduling
[PickupTaskArray,pickupTaskNumMat,pickupTaskBlockWidthVec] = AlgReorganize(MissionSet,robotNum,TRNum);  %one-shot allocation

tic;
%[BRMat,TaskSchedules,makespan] = coupledTaskScheduling();
toc;
figure(1);


%save("idealTS.mat","BRMat","TaskSchedules","makespan");
load("idealTS.mat");
fprintf("Score is %d\n",makespan);
plotGantt(TaskSchedules);

%% Phase-based multi-robot path planning
[rowSequence,colSequence] = rank2sequence(BRMat,pickupTaskNumMat,pickupTaskBlockWidthVec);
maxPhase = max(max(max(rowSequence)),max(max(colSequence)));

m = PRNum;
n = TRNum;
CurrentTime=zeros(robotNum,1);
CurrentLocations=zeros(robotNum,2);
for i=1:m+n
    CurrentLocations(i,:)=RobotSet{i,1}.State;
end

%% keep record task ID and sequences
TaskIndexList = cell(robotNum,1);
for j=1:TRNum
    if j == 1
        index = 0;
    else
        index = sum(pickupTaskBlockWidthVec(1,1:j-1));
    end
    temp=[];
    for i=1:m
        if pickupTaskNumMat(i,j)~=0
            vec = colSequence(i,index+1:index+pickupTaskNumMat(i,j));
            mat=[vec; PickupTaskArray{i,j}']';
            temp=[temp;mat];
        end
    end
    TaskIndexList{j,1}=temp;
end

for i=1:m
    temp=[];
    index = 0;
    for j=1:n
        if pickupTaskNumMat(i,j)~=0
            vec = rowSequence(i,index+1:index+pickupTaskNumMat(i,j));
            mat = [vec; PickupTaskArray{i,j}']';
            temp=[temp;mat];
        end
        index = index + pickupTaskBlockWidthVec(1,j);
    end
    TaskIndexList{n+i,1}=temp;
end

CurrentTS = [];
FineTaskSchedules = TaskSchedules;
%% Phase-based MAPF
for phase = 1:maxPhase
    %% formulation of TA-MAPF-TC
    StartTS = zeros(robotNum,3);
    GoalTS = zeros(robotNum,3);
    for i = 1:robotNum
        mat=TaskIndexList{i,1};
        if ~isempty(mat)
            currentID = mat(mat(:,1)==phase,:);
        else
            continue;
        end
        
        if ~isempty(currentID)
            mat = FineTaskSchedules{currentID(1,2),1};
            currentTask = mat(currentID(1,3),:);
            if i<=TRNum % transport robots
                StartTS(i,:) = [CurrentLocations(i,:),currentTask(1,7)];
                GoalTS(i,:) = [currentTask(1,4:5),currentTask(1,9)]; % not arrive time
            else
                StartTS(i,:) = [CurrentLocations(i,:),currentTask(1,11)];
                GoalTS(i,:) = [currentTask(1,4:5),currentTask(1,13)]; % not arrive time
            end
        end
    end
    
    planFutureTime = 100;
    %% TA-MAPF-TC by CBS
    %    [successFlag,costVec,maxLateness,computeTime,PathCell] = MRPP_CBS_ST(robotNum,warehouse.MapGrid,StartRobotStates,GoalRobotStates,planTime);
    maxLateness = 10*randi([1 6]);
    %% reshape fine task schedules
    for i=1:missionNum
        mat=TaskIndexList{i,1};
        if ~isempty(mat)
            currentID = mat(mat(:,1)==phase,:);
        else
            continue;
        end
        
        if ~isempty(currentID)
            mat = FineTaskSchedules{i,1};
            mat(currentID(1,3),8:10) = mat(currentID(1,3),8:10) + maxLateness;
            mat(currentID(1,3),12:14) = mat(currentID(1,3),12:14) + maxLateness;
            mat(currentID(1,3),15) = 1;
            indices = mat(:,15) == 0 ;
            for j = indices'
                mat(j,7:14) = mat(j,7:14) + maxLateness;
            end
            FineTaskSchedules{i,1} = mat;
            
            vec = FineTaskSchedules{i,2};
            vec(1,7:8) = vec(1,7:8)+maxLateness;
            FineTaskSchedules{i,2} = vec;
        end                      
    end        
end

figure(2);
plotGantt(TaskSchedules);

%% main loop
AllMissionFinishedVec = zeros(missionNum,1);
SOCVec = zeros(missionNum,2);
while(sum(AllMissionFinishedVec)~=missionNum)   
    
    for i=1:robotNum
        currentTSTable = [];
        for j = 1:robotNum
            if j~=i
                currentTSTable = [currentTSTable;PathCell{j,1}];
            end
        end
        MessagePassing{i,1} = RobotSet{i,1}.robotUpdate(MissionSet,PickupTaskArray,pickupTaskNumMat,pickupTaskBlockWidthVec,BRMat,WarehouseMap.MapGrid,currentTSTable,simTime);        
        PathCell{i,1} = RobotSet{i,1}.DummyPath;
    end
    for i=1:missionNum
        MissionSet{i,1}.update(MessagePassing,simTime);        
        if MissionSet{i,1}.State == 2 % finished            
            AllMissionFinishedVec(i,1) = 1;
            if SOCVec(i,2) == 0
                SOCVec(i,1) = simTime;
                SOCVec(i,2) = 1;
            end            
        end
    end
    
    for i=1:robotNum
        NextRobotStates(i,:)=RobotSet{i,1}.State;
    end
            
    %% display and video generation
    for i=0:frameRate-1
        tempRobotStates = CurrentRobotStates+i*(NextRobotStates-CurrentRobotStates)/frameRate;
        plotAll(WarehouseMap,MissionSet,TRNum,tempRobotStates,ColorMat);
        if enableVideo == 1
            frame = getframe;
            writeVideo(video,frame);
        else
            %pause(0.2/frameRate);
            %pause(0.001);
        end        
        cla;
    end
    CurrentRobotStates = NextRobotStates;
    simTime = simTime+1;
end

figure(3);
AlgPlotMissionGantt(MissionSet,pickupTaskNumMat,ColorMat);

