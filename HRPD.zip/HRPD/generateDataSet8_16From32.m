clear;
clc;
%rng default

% some effects

n=8; % pick robot number
combinationNum = 50;
NewInstanceSet = cell(6,combinationNum);

global WarehouseMap
load('WarehouseMap8.mat');
WorkZones = WarehouseMap.WorkZones;
load("Instance8S.mat");

for p=1:6
    m = 5*p;
    taskNum = m; % task number
    for q=1:combinationNum
        PickRobotSet = cell(n,1);
        for j=1:n
            PickRobotSet{j,1}=ClassPickRobot;
            type = 1;
            PickRobotSet{j,1}.setAttribute(j,type,[],WorkZones(j,:) );
        end
        
        TransportRobotSet = InstanceSet{p,q}.TransportRobotSet;
        
        oldTaskSet = InstanceSet{p,q}.TaskSet;
        TaskSet = cell(taskNum,1);
        
        for i=1:taskNum
            TaskSet{i,1}=ClassTask;
            subtaskNum = 10;
            currentPickupStations = oldTaskSet{i,1}.PickupSubtaskMat(:,6:7);
            pickupZones = zeros(subtaskNum,1);
            for j = 1:subtaskNum
                loc = currentPickupStations(j,:) ;
                for k = 1:size(WorkZones,1)
                    zone = WorkZones(k,:);
                    if loc(1,1)>=zone(1,1) && loc(1,1)<=zone(1,2) && loc(1,2)>=zone(1,3) && loc(1,2)<=zone(1,4)
                        pickupZones(j,1) = k;
                        break;
                    end
                end
            end
                        
            TaskSet{i,1}.setAttribute(i,subtaskNum,currentPickupStations,pickupZones,TransportRobotSet{i,1}.State,oldTaskSet{i,1}.MinRouteTime);
        end
        
        instance.TransportRobotSet = TransportRobotSet;
        instance.PickRobotSet = PickRobotSet;
        instance.TaskSet = TaskSet;
        NewInstanceSet{p,q} = instance;
        fprintf("%d,%d,\n",p,q);
    end
end

InstanceSet = NewInstanceSet;
save("Instance8L.mat","InstanceSet");
