classdef ClassRobot<handle
    
    properties
        ID
        Type %[0=transport robot, 1=pick robot]
        State %[x,y]
        
        TaskID
        SubtaskID        
        Workzone %[xmin,xmax,ymin,ymax]. only for pick robots
        
        TaskSequence
        TaskCount
        
        Path
        DummyPath
        DummyLength
        
        Status %0: idle; 1: on the road; 2: on the pick station 3:picking
        Statistics
    end
    
    methods
        function obj = ClassRobot()
            obj.TaskID = 0;
            obj.SubtaskID = zeros(1,2); %��Ϊ����id�����������������������״̬
            obj.Workzone = zeros(1,4);
            obj.DummyLength = 100;
            obj.TaskCount = 0;
            obj.Status = 0;
            obj.Statistics=zeros(1,4);
        end
        
        %Initialize the robot.
        function setAttribute(obj,id,type,initialState,workZone)
            obj.ID = id;
            obj.Type = type;
            obj.State = initialState;
            if obj.Type == 1 %pick robot
                %obj.Workzone = [initialState(1,1)-5  initialState(1,1)+5 initialState(1,2)-1  initialState(1,2)+1 ];
                obj.Workzone = workZone;
                initialState = [workZone(1,1)+5,workZone(1,3)+2];
                obj.State = initialState;
            end
        end
        
        function taskPlanning(obj,sequenceMat,subSubtaskIDCell,pickupTaskNumMat,pickupTaskBlockWidthVec)
            obj.TaskCount = obj.TaskCount + 1;
            [pickOrderMat, transportOrderMat]=sequence2order(sequenceMat,pickupTaskNumMat,pickupTaskBlockWidthVec);
            [m,n] = size(pickupTaskNumMat);
            if obj.Type == 0 %vertical, transport robot 
                pureID = obj.ID-m;
                totalTaskSum = sum(pickupTaskNumMat(:,pureID));
                
                if obj.TaskCount <= totalTaskSum
                    tempBlockMat = transportOrderMat;
                    if pureID == 1
                        tempBlockMat(:,pickupTaskBlockWidthVec(1,1)+1:end)=0;
                    else
                        temp = sum(pickupTaskBlockWidthVec(1,1:pureID));
                        tempBlockMat(:,1:temp-pickupTaskBlockWidthVec(1,pureID))=0;
                        tempBlockMat(:,temp+1:end)=0;
                    end                  
                    [r,c] = find(tempBlockMat==obj.TaskCount);
                    currentID = subSubtaskIDCell{r,c};
                    obj.TaskID = currentID(1,1);
                    obj.SubtaskID = currentID(1,2);
                elseif obj.TaskCount == totalTaskSum +1
                    obj.TaskID = pureID;
                    obj.SubtaskID = 0;
                else
                    obj.TaskID = 0;
                    obj.SubtaskID = 0;
                end
            else
                totalTaskSum = sum(pickupTaskNumMat(obj.ID,:));            
                if obj.TaskCount <= totalTaskSum
                    [r,c] = find(pickOrderMat(obj.ID,:)==obj.TaskCount);
                    currentID = subSubtaskIDCell{obj.ID,c};
                    obj.TaskID = currentID(1,1);
                    obj.SubtaskID = currentID(1,2);
                else
                    obj.TaskID = 0;
                    obj.SubtaskID = 0;
                end
            end
        end
                
        %path planning
        function pathPlanning(obj,mapGrid,goal,ctime,currentTSInfo)
            enableIdeal = 1;
            tempMap=mapGrid;
            tempTS=currentTSInfo;
            localMapExpand = 1;
            if obj.Type == 1 %only plan locally for pick robots
                height = size(mapGrid,1);
                tempZone = obj.Workzone;
                tempRMin = height+1-tempZone(1,4);
                tempRMax = height+1-tempZone(1,3);
                tempCMin=tempZone(1,1);
                tempCMax=tempZone(1,2);
                tempMap(1:tempRMin-localMapExpand,:)=1;
                tempMap(tempRMax+localMapExpand:height,:)=1;
                tempMap(:,1:tempCMin-localMapExpand)=1;
                tempMap(:,tempCMax+localMapExpand)=1;
                if ~isempty(tempTS)
                    tempTS = tempTS(tempTS(:,1)>=tempZone(1,1)-localMapExpand & tempTS(:,1)<=tempZone(1,2)+localMapExpand & tempTS(:,2)>=tempZone(1,3)-localMapExpand & tempTS(:,2)<=tempZone(1,4)+localMapExpand,:);
                end
            end
            tempPath=AlgSinglePlanner(tempMap,obj.State,goal,ctime,tempTS);
            obj.Path = tempPath;
            if enableIdeal == 1
                tempPath=AlgSinglePlanner(tempMap,obj.State,goal,ctime,[]);
                obj.Path = tempPath;
            end
                        
        end
        
        %state machine
        function ret = robotUpdate(obj,taskSet,subSubtaskIDCell,subtaskDistributionMat,blockWidthVec,sequenceMat,mapGrid,currentTSInfo,ctime)
            
            ret.Type = obj.Type;
            ret.TaskID = 0;
            ret.SubtaskID = 0;
            ret.Property = 0;
            ret.Value = 0;
                        
            switch obj.Status
                case 0 %idle
                    obj.taskPlanning(sequenceMat,subSubtaskIDCell,subtaskDistributionMat,blockWidthVec);
                    sb = repmat(obj.State,100,1);
                    sb(1:100,3) = (ctime:ctime+100-1)';
                    obj.DummyPath = sb;
                    if obj.TaskID ~= 0
                        obj.Status = 1;
                        
                        ret.Type = obj.Type;
                        ret.TaskID = obj.TaskID;
                        ret.SubtaskID = obj.SubtaskID;
                        if obj.Type == 0
                            ret.Property = 9;%TRST
                        else
                            ret.Property = 13;%PRST
                        end
                        ret.Value = ctime;
                        
                        task = taskSet{obj.TaskID,1};
                        goal = task.PickupSubtaskMat(obj.SubtaskID,6:7);
                        if obj.Type ==1
                            goal(1,1) = goal(1,1)+1;
                        end                        
                        obj.pathPlanning(mapGrid,goal,ctime,currentTSInfo);
                        sb = repmat(obj.Path(end,1:2),obj.DummyLength,1);
                        sb(1:100,3) = (obj.Path(end,3)+1:obj.Path(end,3)+obj.DummyLength)';
                        obj.DummyPath = [obj.Path;sb];
                    end
                    obj.Statistics(1,1) = obj.Statistics(1,1) + 1;
                case 1 %Traveling
                    path = obj.Path;
                    obj.State=path(1,1:2);
                    if size(path,1)>1
                        obj.Path = path(2:end,:);
                        
                        ret.Type = obj.Type;
                        ret.TaskID = obj.TaskID;
                        ret.SubtaskID = obj.SubtaskID;
                        if obj.Type == 0
                            ret.Property = 18;%TR remaining time
                        else
                            ret.Property = 19;%PR remaining time
                        end
                        ret.Value = size(obj.Path,1);
                    else
                        obj.Status = 2;
                        
                        ret.Type = obj.Type;
                        ret.TaskID = obj.TaskID;
                        ret.SubtaskID = obj.SubtaskID;
                        if obj.Type == 0
                            ret.Property = 10;%TRAT
                        else
                            ret.Property = 14;%PRAT
                        end
                        ret.Value = ctime;
                    end
                    sb = repmat(obj.Path(end,1:2),obj.DummyLength,1);
                    sb(1:100,3) = (obj.Path(end,3)+1:obj.Path(end,3)+obj.DummyLength)';
                    obj.DummyPath = [obj.Path;sb];
                    obj.Statistics(1,2) = obj.Statistics(1,2) + 1;
                    
                case 2 %On the station or depot
                    sb = repmat(obj.State,obj.DummyLength,1);
                    sb(1:obj.DummyLength,3) = (ctime:ctime+obj.DummyLength-1)';
                    obj.DummyPath = sb;
                    if obj.TaskID ~= 0 && obj.SubtaskID ~= 0  % pickup subtask
                        task = taskSet{obj.TaskID,1};
                        if task.PickupSubtaskMat(obj.SubtaskID,17) == 1
                            obj.taskPlanning(sequenceMat,subSubtaskIDCell,subtaskDistributionMat,blockWidthVec);
                            if  obj.TaskID ~=0 && obj.SubtaskID~=0 %pickup subtask
                                
                                ret.Type = obj.Type;
                                ret.TaskID = obj.TaskID;
                                ret.SubtaskID = obj.SubtaskID;
                                if obj.Type == 0
                                    ret.Property = 9;%TRST
                                else
                                    ret.Property = 13;%PRST
                                end
                                ret.Value = ctime;
                                
                                task = taskSet{obj.TaskID,1};
                                goal = task.PickupSubtaskMat(obj.SubtaskID,6:7);
                                if obj.Type ==1
                                    goal(1,1) = goal(1,1)+1;
                                end 
                                obj.pathPlanning(mapGrid,goal,ctime,currentTSInfo);
                                sb = repmat(obj.Path(end,1:2),obj.DummyLength,1);
                                sb(1:obj.DummyLength,3) = (obj.Path(end,3)+1:obj.Path(end,3)+obj.DummyLength)';
                                obj.DummyPath = [obj.Path;sb];
                                obj.Status = 1;
                            elseif obj.TaskID ~=0 && obj.SubtaskID==0 % delivery task
                                ret.Type = obj.Type;
                                ret.TaskID = obj.TaskID;
                                ret.SubtaskID = obj.SubtaskID;
                                if obj.Type == 0
                                    ret.Property = 9;%TRST
                                else
                                    ret.Property = 13;%PRST
                                end
                                ret.Value = ctime;
                                
                                task = taskSet{obj.TaskID,1};
                                goal = task.DeliveryTaskVec(1,6:7);
                                obj.pathPlanning(mapGrid,goal,ctime,currentTSInfo);
                                sb = repmat(obj.Path(end,1:2),obj.DummyLength,1);
                                sb(1:obj.DummyLength,3) = (obj.Path(end,3)+1:obj.Path(end,3)+obj.DummyLength)';
                                obj.DummyPath = [obj.Path;sb];
                                obj.Status = 1;
                            elseif obj.TaskID ==0 && obj.SubtaskID==0 % empty task
                                obj.Status = 3;
                            end
                            obj.Statistics(1,4) = obj.Statistics(1,4) + 1;
                        else  %not finished yet
                            obj.Statistics(1,3) = obj.Statistics(1,3) + 1;% idle times
                        end
                    elseif obj.TaskID ~= 0 && obj.SubtaskID == 0   % delivery task
                        task = taskSet{obj.TaskID,1};
                        if task.DeliveryTaskVec(1,17) == 1
                            obj.Status = 3;
                            obj.Statistics(1,4) = obj.Statistics(1,4) + 1;
                        else
                            obj.Statistics(1,3) = obj.Statistics(1,3) + 1;% idle times
                        end
                    end
                    
                case 3 % do nothing
                    
            end %end of switch
            
        end %end of update function
        
    end
end
