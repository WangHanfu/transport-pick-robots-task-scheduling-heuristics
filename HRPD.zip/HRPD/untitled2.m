load('WarehouseMapLarge.mat');
figure(1);

sz=get(0,'screensize');
sz(1,2) = 10;
sz(1,4) = 1080;
figure(2);
h=figure('outerposition',sz);
assignin('base','h',h); %in case of any callback errors.
%title('Large-scale Heterogeneous Multi-Robot System in Warehouse');
hold on;
grid on;
set(gca,'xtick',0:1:WarehouseMap.Width);
set(gca,'ytick',0:1:WarehouseMap.Height);
axis equal;
axis([0 WarehouseMap.Width+1 0 WarehouseMap.Height+1]);
axis manual;

plotMap(WarehouseMap);

n=16;

WorkZones=zeros(n,4);
WorkZones(1,:)=[4 13 5 11];
WorkZones(2,:)=[16 25 5 11];
WorkZones(3,:)=[28 37 5 11];
WorkZones(4,:)=[40 49 5 11];
for i=1:3
    WorkZones(1+i*4,:)=[4 13 5+i*8 11+i*8];
    WorkZones(2+i*4,:)=[16 25 5+i*8 11+i*8];
    WorkZones(3+i*4,:)=[28 37 5+i*8 11+i*8];
    WorkZones(4+i*4,:)=[40 49 5+i*8 11+i*8];
end

WarehouseMap.WorkZones = WorkZones;
figure(2);
sz=get(0,'screensize');
sz(1,2) = 10;
sz(1,4) = 1080;
figure(2);
h=figure('outerposition',sz);
assignin('base','h',h); %in case of any callback errors.
%title('Large-scale Heterogeneous Multi-Robot System in Warehouse');
hold on;
grid on;
set(gca,'xtick',0:1:WarehouseMap.Width);
set(gca,'ytick',0:1:WarehouseMap.Height);
axis equal;
axis([0 WarehouseMap.Width+1 0 WarehouseMap.Height+1]);
axis manual;
plotMap(WarehouseMap);

save('WarehouseMap16.mat','WarehouseMap');

%% 
load('WarehouseMapLarge.mat');
n=8;

WorkZones=zeros(n,4);
WorkZones(1,:)=[4 25 5 11];
WorkZones(2,:)=[28 49 5 11];
for i=1:3
    WorkZones(1+i*2,:)=[4 25 5+i*8 11+i*8];
    WorkZones(2+i*2,:)=[28 49 5+i*8 11+i*8];
end

WarehouseMap.WorkZones = WorkZones;
figure(3);
sz=get(0,'screensize');
sz(1,2) = 10;
sz(1,4) = 1080;
figure(2);
h=figure('outerposition',sz);
assignin('base','h',h); %in case of any callback errors.
%title('Large-scale Heterogeneous Multi-Robot System in Warehouse');
hold on;
grid on;
set(gca,'xtick',0:1:WarehouseMap.Width);
set(gca,'ytick',0:1:WarehouseMap.Height);
axis equal;
axis([0 WarehouseMap.Width+1 0 WarehouseMap.Height+1]);
axis manual;
plotMap(WarehouseMap);

save('WarehouseMap8.mat','WarehouseMap');